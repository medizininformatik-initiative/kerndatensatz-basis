# Translation Information - MII Implementation Guide Core Dataset Base v2026.0.0-dev.1

## Translation Information

### Translation Information

This implementation guide has been translated into German and English. Every effort has been made to ensure accurate translations. In the event of discrepancies between the translations, please provide feedback and suggest improvements.

