# MII VS Prozedur Prozeduren [SNOMED CT] - MII Implementation Guide Core Dataset Base v2026.0.0

## ValueSet: MII VS Prozedur Prozeduren [SNOMED CT] 

 
Enthaelt alle SNOMED CT Procedure Codes 

 **References** 

* [MII PR Prozedur Procedure](StructureDefinition-mii-pr-prozedur-procedure.md)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "mii-vs-prozedur-prozeduren-snomedct",
  "meta" : {
    "extension" : [{
      "url" : "http://hl7.org/fhir/uv/crmi/StructureDefinition/crmi-license",
      "valueCodeableConcept" : {
        "coding" : [{
          "system" : "http://hl7.org/fhir/spdx-license",
          "code" : "CC-BY-4.0",
          "display" : "Creative Commons Attribution 4.0 International"
        }]
      }
    }]
  },
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/artifact-versionAlgorithm",
    "valueCoding" : {
      "system" : "http://hl7.org/fhir/version-algorithm",
      "code" : "semver",
      "display" : "SemVer"
    }
  }],
  "url" : "https://www.medizininformatik-initiative.de/fhir/core/modul-prozedur/ValueSet/procedures-sct",
  "version" : "2026.0.0",
  "name" : "MII_VS_Prozedur_Prozeduren_SNOMEDCT",
  "title" : "MII VS Prozedur Prozeduren [SNOMED CT]",
  "status" : "active",
  "experimental" : false,
  "date" : "2025-12-12",
  "publisher" : "Medical Informatics Initiative (MII)",
  "_publisher" : {
    "extension" : [{
      "extension" : [{
        "url" : "lang",
        "valueCode" : "de"
      },
      {
        "url" : "content",
        "valueString" : "Medizininformatik-Initiative (MII)"
      }],
      "url" : "http://hl7.org/fhir/StructureDefinition/translation"
    }]
  },
  "contact" : [{
    "name" : "Medical Informatics Initiative (MII)",
    "telecom" : [{
      "system" : "url",
      "value" : "https://www.medizininformatik-initiative.de/en"
    }]
  }],
  "description" : "Enthaelt alle SNOMED CT Procedure Codes",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "DE",
      "display" : "Germany"
    }]
  }],
  "copyright" : "This material includes SNOMED Clinical Terms® (SNOMED CT®) which is used by permission of SNOMED International. All rights reserved. SNOMED CT®, was originally created by The College of American Pathologists. SNOMED and SNOMED CT are registered trademarks of SNOMED International. Implementers of these artefacts must have the appropriate SNOMED CT Affiliate license.",
  "compose" : {
    "include" : [{
      "system" : "http://snomed.info/sct",
      "version" : "http://snomed.info/sct/900000000000207008/version/20250701",
      "filter" : [{
        "property" : "concept",
        "op" : "descendent-of",
        "value" : "71388002"
      }]
    }]
  }
}

```
