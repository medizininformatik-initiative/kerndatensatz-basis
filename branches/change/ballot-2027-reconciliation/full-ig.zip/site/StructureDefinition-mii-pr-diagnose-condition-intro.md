**Example Usage Scenarios:**

- Document diagnoses for patients in clinical care using ICD-10-GM coding
- Support billing and administrative processes with coded diagnosis information
- Enable epidemiological research and disease surveillance through standardized diagnosis coding
- Represent rare diseases using Alpha-ID or Orphanet codes alongside ICD-10-GM
- Link diagnoses to specific encounters for temporal and contextual documentation

### Profile Specific Implementation Guidance

This section provides detailed implementation guidance for the MII Diagnose (Diagnosis) Profile.

#### Coding Requirements

**Mandatory Coding:**
- **`Condition.code`**: At least one coded diagnosis **MUST** be present
- Code system may be freely selected from: ICD-10-GM, Alpha-ID, SNOMED CT, or Orphanet
- ICD-10-GM coding is the primary coding system for diagnoses in Germany

**Multiple Code Systems:**
- Multiple codings from different terminologies are permitted and encouraged where applicable
- Example: ICD-10-GM for billing/administrative purposes + SNOMED CT for semantic interoperability + Alpha-ID/Orphanet for rare diseases

#### ICD-10-GM Specific Extensions

<div style="background-color: #E8F4F8; border-left: 5px solid #5C8DB3; padding: 15px; margin: 10px 0;">
<h5 style="color: #406A99; margin-top: 0;">Best Practice - ICD-10-GM Extensions and Special Characters</h5>

<p><strong>Separation of Special Characters:</strong> The element <code>Condition.code.coding.where(system='http://fhir.de/CodeSystem/bfarm/icd-10-gm').code</code> <strong>SHOULD NOT</strong> contain multi-coding markers or additional markers (e.g., laterality or diagnostic certainty).</p>

<p><strong>Extension Usage:</strong></p>
<ul>
  <li><strong>Mehrfachcodierungs-Kennzeichen:</strong> Multi-coding markers (<code>*</code>, <code>†</code>, <code>!</code>) <strong>SHOULD</strong> be separated from ICD-10-GM codes and captured in the "Mehrfachcodierungs-Kennzeichen" extension</li>
  <li><strong>Seitenlokalisation:</strong> The "Seitenlokalisation" extension <strong>SHOULD</strong> be used to specify laterality in ICD-10-GM coding</li>
  <li><strong>Diagnosesicherheit:</strong> The "Diagnosesicherheit" extension <strong>SHOULD</strong> be used to specify diagnostic certainty in ICD-10-GM coding</li>
</ul>

<p><strong>Reference:</strong> See <a href="https://ig.fhir.de/basisprofile-de/1.5.4/ig-markdown-Datentypen-Coding.html#ig-markdown-Datentypen-ICD-10GM-Coding">ICD-10-GM Coding Profile</a> and <a href="https://ig.fhir.de/basisprofile-de/1.5.4/ig-markdown-ExtensionsfrCondition.html">Diagnosesicherheit Extension</a> in the German Base Profiles for detailed constraints.</p>
</div>

#### Multi-Coding with ICD-10-GM Cross-Dagger System

<div style="background-color: #E8F4F8; border-left: 5px solid #5C8DB3; padding: 15px; margin: 10px 0;">
<h5 style="color: #406A99; margin-top: 0;">Best Practice - Cross-Dagger (Kreuz-Stern) System Implementation</h5>

<p><strong>Multiple Condition Instances:</strong> When using ICD-10-GM codes with the cross-dagger system (Kreuz-Stern), create a <strong>separate Condition instance for each ICD-10 code</strong> (etiology, manifestation, additional information).</p>

<p><strong>Linking Secondary to Primary:</strong></p>
<ul>
  <li>The primary diagnosis Condition (etiology/Ätiologie with † marker) is the main instance</li>
  <li>Secondary diagnosis Conditions (manifestation/Manifestation with * marker, additional information with ! marker) use the <a href="http://hl7.org/fhir/R4/extension-condition-related.html">Condition Related Extension</a> to reference the primary diagnosis</li>
  <li>This creates an explicit relationship chain: manifestation → etiology</li>
</ul>

<p><strong>Alpha-ID and Orphanet Codes:</strong></p>
<ul>
  <li>When Alpha-ID or Orphanet codes are mapped to combined ICD-10-GM codes, include them <strong>only in the primary diagnosis Condition instance</strong></li>
  <li>Do not duplicate Alpha-ID/Orphanet codes in secondary Condition instances</li>
</ul>

<p><strong>Diagnostic Certainty Considerations:</strong></p>
<ul>
  <li>If diagnostic certainty differs between primary and secondary diagnoses, ensure the certainty of the primary Condition applies to the associated Alpha-ID</li>
  <li>This prevents inconsistencies when rare disease codes (Alpha-ID/Orphanet) are associated with uncertain etiological diagnoses</li>
</ul>

<p><strong>Example:</strong> See example resources for Alpha-ID <code>I97525</code> with ICD-10-GM <code>A54.4†</code> (etiology) and <code>M73.09*</code> (manifestation).</p>
</div>

#### Body Site Documentation

The modeling of coded and detailed anatomical locations has been harmonized with [gematik ISiK Diagnosis 6.0.0](https://gemspec.gematik.de/ig/fhir/isik/basis/6.0.0/StructureDefinition-ISiKDiagnose.html). `Condition.bodySite` supports two representations:

- a coded anatomical location, preferably using SNOMED CT; or
- a reference to a patient-specific `BodyStructure` via the `http://hl7.org/fhir/StructureDefinition/bodySite` extension when a coded body site alone does not provide the required detail.

**EHDS outlook:** [HL7 Europe Condition (EU core) 2.0.0](https://hl7.eu/fhir/base/2.0.0/StructureDefinition-condition-eu-core.html) uses the same coded-or-referenced representation and applies the `eu-bodysite-1` invariant. For future EHDS compatibility, each `Condition.bodySite` occurrence **SHOULD** contain either coding/text or the BodyStructure-reference extension, but not both.

**`Condition.bodySite`:**
- OPTIONAL element
- If used, body site **SHOULD** be coded with at least one SNOMED CT code
- Use the BodyStructure-reference extension when the coded body site is not sufficiently precise
- For ICD-10-GM laterality, use the Seitenlokalisation extension on `Condition.code.coding:icd10-gm` instead of encoding laterality in `bodySite`

#### Encounter Linkage

<div style="background-color: #E8F4F8; border-left: 5px solid #5C8DB3; padding: 15px; margin: 10px 0;">
<h5 style="color: #406A99; margin-top: 0;">Best Practice - Diagnosis-Encounter Relationships</h5>

<p><strong>Change from Previous Version:</strong> In previous versions of this implementation guide, it was recommended to use <code>Encounter.diagnosis</code> to link diagnoses to encounters. This guidance has been updated to align with gematik ISiK (Informationssysteme im Krankenhaus) recommendations.</p>

<p><strong>Current Recommendation - Condition.encounter:</strong></p>
<ul>
  <li><strong>Department Contact Level:</strong> The reference <strong>SHOULD</strong> be to an Encounter at the "Abteilungskontakt" (department contact) level.</li>
  <li>When selecting the Encounter, note that multiple Encounters may be grouped under a single (billing) case number (<code>Encounter.account</code>), such as an inpatient visit with multiple pre- and post-hospitalization contacts</li>
</ul>

</div>

#### Temporal Information

<div style="background-color: #E8F4F8; border-left: 5px solid #5C8DB3; padding: 15px; margin: 10px 0;">
<h5 style="color: #406A99; margin-top: 0;">Best Practice - Onset and Abatement</h5>

<p>The modeling of disease onset and abatement has been harmonized with <a href="https://gemspec.gematik.de/ig/fhir/isik/basis/6.0.0/StructureDefinition-ISiKDiagnose.html">gematik ISiK</a>. Implementers <strong>SHOULD</strong> use <code>onsetDateTime</code>/<code>abatementDateTime</code> for dates and <code>onsetRange</code>/<code>abatementRange</code> with the life-phase extension when only a life phase is known. <code>onsetPeriod</code> and <code>abatementPeriod</code> remain permitted solely for backwards compatibility and <strong>SHOULD NOT</strong> be used in new implementations.</p>

<p><strong>EHDS outlook:</strong> The published trial-use <a href="https://hl7.eu/fhir/base/2.0.0/StructureDefinition-condition-eu-core.html">HL7 Europe Condition (EU core) 2.0.0 profile</a>, which informs upcoming EHDS specifications, explicitly profiles the <code>dateTime</code> variants of onset and abatement. To facilitate future EHDS compliance, new implementations <strong>SHOULD</strong> therefore use <code>onsetDateTime</code> and <code>abatementDateTime</code> whenever a date is available.</p>
</div>

**`Condition.onset[x]`:**
- **SHOULD** be captured as `dateTime`, `Age` or `Range`
- When using `Range`, the life-phase extension **MAY** specify a life phase as a code if the exact date is unknown
- `Period` remains allowed for backwards compatibility but **SHOULD NOT** be used
- Represents when the condition began or was first noticed

**`Condition.abatement[x]`:**
- **SHOULD** be captured as `dateTime`, `Age` or `Range`
- When using `Range`, the life-phase extension **MAY** specify a life phase as a code if the exact date is unknown
- `Period` remains allowed for backwards compatibility but **SHOULD NOT** be used
- Represents when the condition ended, resolved, or entered remission

<div style="background-color: #FFF8E1; border-left: 5px solid #E0A800; padding: 15px; margin: 10px 0;">
<h5 style="color: #8A6D00; margin-top: 0;">Note - Life phase on <code>Range</code> instead of <code>Age</code></h5>

<p>The life-phase extension <code>http://fhir.de/StructureDefinition/lebensphase</code> (<a href="https://simplifier.net/packages/de.basisprofil.r4/1.6.0">de.basisprofil.r4</a> 1.6.0) may only be used on <code>dateTime</code>, <code>Period.start</code>, <code>Period.end</code> and <code>Range</code>. It is therefore profiled on <code>onsetRange</code> and <code>abatementRange</code>, no longer on <code>onsetAge</code> and <code>abatementAge</code> (<a href="https://hl7germany.atlassian.net/browse/HDB-1075">HDB-1075</a>). <code>Age</code> remains allowed without the extension. This deviates from <a href="https://gemspec.gematik.de/ig/fhir/isik/basis/6.0.0/StructureDefinition-ISiKDiagnose.html">ISiK Basis 6.0.0</a>, which profiles the extension on <code>Age</code>.</p>

<p>The <a href="https://hl7.eu/fhir/extensions/StructureDefinition-periods-of-life.html">HL7 Europe extension <code>periods-of-life</code></a> also allows <code>Age</code> as context. If the context of the German extension changes in a future release of the German base profiles, or the EU extension is adopted, the placement will be reviewed.</p>
</div>

**`Condition.recordedDate`:**
- Represents when the diagnosis was recorded in the system

{% include link-list.md %}
