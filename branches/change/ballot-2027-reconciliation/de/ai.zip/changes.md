# Changelog - MII Implementation Guide Core Dataset Base v2027.0.0-ballot

* [**Inhaltsverzeichnis**](toc.md)
* **Changelog**

## Changelog

Diese Seite dokumentiert die Änderungen und Updates über Versionen des MII-Implementierungsleitfadens Kerndatensatz Basis hinweg. Dieses konsolidierte Änderungsprotokoll kombiniert Release Notes aus allen vier Basismodulen: Person, Fall, Diagnose und Prozedur.

-------

### Version 2027.0.0

**Datum:** noch nicht veröffentlicht

Änderungen aus der Ballot-Kommentierung zu `2027.0.0-ballot`. Ab dieser Version beginnt jeder Eintrag mit einem Link auf das betroffene Artefakt.

#### Modul Person

* **Changed:** [MII PR Person Patient](StructureDefinition-mii-pr-person-patient.md), [MII PR Person Patient (Pseudonymisiert)](StructureDefinition-mii-pr-person-patient-pseudonymisiert.md) — Die Invariante `pat-cnt-2or3-char` (Schweregrad warning) an den Adress-Slices prüft jetzt die Extension `Address.country.extension:countryCode` (`iso21090-codedString`, ISO 3166-1 alpha-2) statt `Address.country`, sodass `Address.country` auch andere Werte wie DEÜV-Länderschlüssel enthalten darf. Alpha-3-Codes werden nicht mehr akzeptiert, da `AddressDeBasis` die Extension an alpha-2 bindet (**required**). Die Beispiele codieren das Land jetzt in der Extension. Siehe: [HDB-1069](https://hl7germany.atlassian.net/browse/HDB-1069), [HDB-935](https://hl7germany.atlassian.net/browse/HDB-935)
* **Changed:** [MII PR Person Patient](StructureDefinition-mii-pr-person-patient.md), [MII VS Person Recorded Sex or Gender SNOMED](ValueSet-mii-vs-person-recordedsexorgender-snomed.md) — Die Bindung von `Patient.extension:recordedSexOrGender.extension:value.valueCodeableConcept` an das ValueSet wurde von **preferred** auf **extensible** geändert. Nicht breaking, da die Extension in `2027.0.0-ballot` neu ist. Siehe: [HDB-1124](https://hl7germany.atlassian.net/browse/HDB-1124)
* **Added:** [MII CM Person Recorded Sex or Gender SNOMED to Administrative Gender](ConceptMap-mii-cm-person-recordedsexorgender-snomed-administrative-gender.md) — ConceptMap von den SNOMED-CT-Codes des [MII VS Person Recorded Sex or Gender SNOMED](ValueSet-mii-vs-person-recordedsexorgender-snomed.md) nach `administrative-gender`. Alle Beziehungen sind qualifiziert (**inexact**, **wider**) statt äquivalent, da dokumentiertes und administratives Geschlecht unterschiedliche Konzepte sind. Siehe: [HDB-1068](https://hl7germany.atlassian.net/browse/HDB-1068)
* **Added:** [MII PR Person Patient](StructureDefinition-mii-pr-person-patient.md) — nur Dokumentation: `Patient.birthDate` bleibt bewusst 0..1, anders als in ISiK (1..1 mit `data-absent-reason`); ein Hinweis erläutert die Abweichung. Siehe: [HDB-1071](https://hl7germany.atlassian.net/browse/HDB-1071)
* **Added:** [MII PR Person Patient](StructureDefinition-mii-pr-person-patient.md) — optionale Extension [`patient-sexParameterForClinicalUse`](https://hl7.org/fhir/extensions/StructureDefinition-patient-sexParameterForClinicalUse.html) (`hl7.fhir.uv.extensions.r4` 5.2.0) mit Must Support auf `value` (Coding-System und Code) und `period`. Nicht im pseudonymisierten Patient-Profil und nicht im logischen Modell. Siehe: [HDB-1067](https://hl7germany.atlassian.net/browse/HDB-1067)
* **Changed:** [MII PR Person AllergieUnvertraeglichkeit](StructureDefinition-mii-pr-person-allergieunvertraeglichkeit.md) — Die **preferred**-Bindungen an die IPS-ValueSets an `AllergyIntolerance.code` und `AllergyIntolerance.reaction.manifestation` werden durch optionale Slices `coding:snomed-ct` (0..1, Must Support) ersetzt, die **extensible** an die KBV-ValueSets `KBV_VS_AllergyIntolerance_Substance_SNOMED_CT` 1.0.0 und `KBV_VS_AllergyIntolerance_Manifestation_SNOMED_CT` 1.0.0 gebunden sind, abgestimmt mit ISiK. Die Slices sind nicht verpflichtend, da Allergien auch nur mit anderen Codes, z.B. ATC, dokumentiert sein können. Neue Abhängigkeit `kbv.all.terminology.allergyintolerance` 1.0.0, die nur auf dem [BfArM-ZTS](https://terminologien.bfarm.de) nach Akzeptanz der Downloadbedingungen verfügbar ist. Das Beispiel verwendet jetzt eine Manifestation aus dem KBV-ValueSet. Siehe: [HDB-1073](https://hl7germany.atlassian.net/browse/HDB-1073), [HDB-1019](https://hl7germany.atlassian.net/browse/HDB-1019)
* **Added:** [MII PR Person AllergieUnvertraeglichkeit](StructureDefinition-mii-pr-person-allergieunvertraeglichkeit.md) — Optionale Lebensphasen-Extension `http://fhir.de/StructureDefinition/lebensphase` an `AllergyIntolerance.onsetRange` und an `AllergyIntolerance.extension:abatement.valueRange` (`allergyintolerance-abatement`), mit Must Support auf dem Range und dem Coding der Extension, konsistent mit dem Condition-Profil. Nicht breaking, da das Profil in `2027.0.0-ballot` neu ist. Siehe: [HDB-1072](https://hl7germany.atlassian.net/browse/HDB-1072)
* **Added:** [MII PR Person Patient](StructureDefinition-mii-pr-person-patient.md), [MII PR Fall Kontakt mit einer Gesundheitseinrichtung](StructureDefinition-mii-pr-fall-kontakt-gesundheitseinrichtung.md) — nur Dokumentation: neuer Abschnitt „Mutter und Neugeborenes“ zur Mutter-Kind-Beziehung (`RelatedPerson`, `MTH`), zum optionalen `Encounter.partOf` vom Kontakt des Neugeborenen auf den Entbindungskontakt der Mutter mit Traversierungsregel, zu bedingten Abrechnungsfällen des Neugeborenen, zu Mehrlingsschwangerschaft und Mehrlingsgeburt (`multipleBirth[x]`, Zwillingsbeispiel) sowie zum HL7-v2-Mapping. Siehe: [HDB-1035](https://hl7germany.atlassian.net/browse/HDB-1035), [HDB-1036](https://hl7germany.atlassian.net/browse/HDB-1036)

#### Modul Diagnose

* **Changed:** [MII PR Diagnose Condition](StructureDefinition-mii-pr-diagnose-condition.md), [MII LM Diagnose](StructureDefinition-mii-lm-diagnose.md) — **breaking:** Die Lebensphasen-Extension `http://fhir.de/StructureDefinition/lebensphase` wurde von `onsetAge`/`abatementAge` nach `onsetRange`/`abatementRange` verschoben (`Range` in `onset[x]` und `abatement[x]` ergänzt), da ihr Kontext in `de.basisprofil.r4` 1.6.0 `Age` nicht zulässt. `Age` bleibt ohne die Extension zulässig; das Mapping im logischen Modell wurde angepasst. Der Kontext der deutschen Extension und die HL7-Europe-Extension `periods-of-life` (die `Age` zulässt) werden beobachtet. Siehe: [HDB-1075](https://hl7germany.atlassian.net/browse/HDB-1075)
* **Added:** [MII PR Diagnose Condition](StructureDefinition-mii-pr-diagnose-condition.md) — nur Dokumentation: `extension:Feststellungsdatum` und die Abgrenzung zu `onset[x]` und `recordedDate` mit Beispiel beschrieben sowie die Verwendung von `extension:ReferenzPrimaerdiagnose` präzisiert (Short und Definition ergänzt). Siehe: [HDB-1020](https://hl7germany.atlassian.net/browse/HDB-1020)
* **Added:** [MII PR Diagnose Condition](StructureDefinition-mii-pr-diagnose-condition.md) — nur Dokumentation: Hinweis, dass die empfohlene Kontaktebene für `Condition.encounter` (Abteilungskontakt) für ISiK Stufe 7 diskutiert wird und die MII dem Ergebnis folgen wird. Siehe: [HDB-1012](https://hl7germany.atlassian.net/browse/HDB-1012)

#### Modul Fall

* **Added:** [MII PR Fall Kontakt mit einer Gesundheitseinrichtung](StructureDefinition-mii-pr-fall-kontakt-gesundheitseinrichtung.md) — nur Dokumentation: Tabelle der bewussten Kardinalitätsabweichungen von ISiK 6.0.0 bei `type:Kontaktebene` und `diagnosis.use.coding:Diagnosetyp`; diese Kardinalitäten bleiben unverändert. Siehe: [HDB-1016](https://hl7germany.atlassian.net/browse/HDB-1016)
* **Changed:** [MII PR Fall Kontakt mit einer Gesundheitseinrichtung](StructureDefinition-mii-pr-fall-kontakt-gesundheitseinrichtung.md) — `Encounter.hospitalization.admitSource` von 1..1 auf 0..1 (Must Support) gelockert, wie in ISiK 6.0.0 und im logischen Modell, da der Aufnahmeanlass im HL7-v2-Strom oft nicht vorliegt. Nicht breaking für bestehende Instanzen. Siehe: [HDB-1016](https://hl7germany.atlassian.net/browse/HDB-1016), [#53](https://github.com/medizininformatik-initiative/kerndatensatz-basis/issues/53)
* **Changed:** [MII LM Fall](StructureDefinition-mii-lm-fall.md) — nur Dokumentation: Beschreibungen von **Aufnahmenummer** und **PatientenIdentifikator** korrigiert, die Aufnahmenummer und Fallnummer gleichsetzten. Die Aufnahmenummer identifiziert einen einzelnen Kontakt; die Fallnummer identifiziert den Abrechnungsfall (Account) und wird in `Encounter.account.identifier` angegeben, wie im Encounter-Profil und in ISiK beschrieben. Die übersetzten Definitionen von `identifier:Aufnahmenummer` im Profil wurden angeglichen. Siehe: [HDB-1048](https://hl7germany.atlassian.net/browse/HDB-1048)
* **Added:** [MII PR Fall Kontakt mit einer Gesundheitseinrichtung](StructureDefinition-mii-pr-fall-kontakt-gesundheitseinrichtung.md) — nur Dokumentation: erläutert, warum teilstationäre Kontakte `Encounter.class` `IMP` (mit Bettenzuweisung, z. B. Nachtklinik) oder `SS` (ohne Bettenzuweisung, z. B. Tagesklinik) verwenden können und dass `Encounter.type` und der Aufnahmegrund sie als teilstationär kennzeichnen. Siehe: [HDB-1010](https://hl7germany.atlassian.net/browse/HDB-1010)
* **Changed:** [MII PR Fall Kontakt mit einer Gesundheitseinrichtung](StructureDefinition-mii-pr-fall-kontakt-gesundheitseinrichtung.md) — Der Slice `Encounter.location:Bett` wurde in `Encounter.location:Bettenstellplatz` umbenannt und als Ort beschrieben, an dem das Bett steht, zur Abgrenzung vom Bett als Gerät. Diskriminator, Kardinalität und Einschränkungen bleiben unverändert; nicht breaking, bestehende Instanzen und Implementierungen sind nicht betroffen. Siehe: [HDB-1011](https://hl7germany.atlassian.net/browse/HDB-1011)
* **Added:** [MII PR Fall Kontakt mit einer Gesundheitseinrichtung](StructureDefinition-mii-pr-fall-kontakt-gesundheitseinrichtung.md) — nur Dokumentation: DRG-Haupt- und Nebendiagnosen (`principle-DRG`, `secondary-DRG`) sowie `hospital-main-diagnosis` SOLLEN wie in ISiK am Account mit `ExtensionAbrechnungsDiagnoseProzedur` angegeben werden, nicht in `Encounter.diagnosis.use`; `mii-vs-fall-diagnosis-use` bleibt unverändert. Siehe: [HDB-1052](https://hl7germany.atlassian.net/browse/HDB-1052)
* **Changed:** [UML-Diagramm des Moduls Fall](uml-diagrams.md) — nur Dokumentation: Assoziation von Einrichtungskontakt zu Patient (Modul Person) über **Patientenidentifikator** (`Encounter.subject`) ergänzt. Siehe: [HDB-1013](https://hl7germany.atlassian.net/browse/HDB-1013)
* **Added:** [MII PR Fall Kontakt mit einer Gesundheitseinrichtung](StructureDefinition-mii-pr-fall-kontakt-gesundheitseinrichtung.md) — nur Dokumentation: klargestellt, dass ein Account von mehreren Einrichtungskontakten referenziert werden kann, z. B. vor-/nachstationäre Kontakte oder zusammengeführte Wiederaufnahmen; die Abbildung der Kontakthierarchie zeigt gemeinsame Account-Referenzen bereits (siehe [#73](https://github.com/medizininformatik-initiative/kerndatensatz-basis/issues/73)). Siehe: [HDB-939](https://hl7germany.atlassian.net/browse/HDB-939)
* **Added:** [MII PR Fall Kontakt mit einer Gesundheitseinrichtung](StructureDefinition-mii-pr-fall-kontakt-gesundheitseinrichtung.md) — nur Dokumentation: die beiden Darstellungen einer Station als Location (`location:Station`, `physicalType = wa`) und als Organization (`serviceProvider`) beschrieben, im Einklang mit ISiK 6.0.0. Siehe: [HDB-938](https://hl7germany.atlassian.net/browse/HDB-938)

#### Modul Prozedur

* **Added:** [MII PR Prozedur Procedure](StructureDefinition-mii-pr-prozedur-procedure.md) — nur Dokumentation: Hinweis auf die Unterschiede zu ISiK 6.0.0 bei `proc-ISiK-2` (codierte Kategorie für jede codierte Prozedur) und `proc-ISiK-3` (rein textueller Prozedur-Code). Die MII-Invarianten `proc-mii-1` und `sct-ops-1` bleiben unverändert. Siehe: [HDB-1018](https://hl7germany.atlassian.net/browse/HDB-1018)
* **Changed:** [MII PR Prozedur Procedure](StructureDefinition-mii-pr-prozedur-procedure.md) — nur Dokumentation: Definition von `bodySite` präzisiert (SNOMED-CT-Prozedurcodes enthalten Körperstelle und Lateralität in der Regel präkoordiniert; `bodySite` SOLL diese nicht lediglich wiederholen) und erläutert, warum keine Invariante redundante Seitenangaben prüft. Siehe: [HDB-1077](https://hl7germany.atlassian.net/browse/HDB-1077)

### Version 2027.0.0-ballot

**Datum:** 2026-09-10

#### Dokumentation

* **Added:** Allgemeine Leitlinien zum Umgang mit Storno-Kennzeichen aus Quellsystemen ergänzt, einschließlich ressourcenspezifischer Statusabbildungen, Filterung bei der Erstbeladung, späterer Korrekturen und Filterung für die Datennutzung. Siehe: [#71](https://github.com/medizininformatik-initiative/kerndatensatz-basis/issues/71)
* **Changed:** Abhängigkeiten auf `de.basisprofil.r4` 1.6.0, `de.medizininformatikinitiative.kerndatensatz.meta` 2027.0.0-ballot, `hl7.terminology.r4` 7.1.0, `hl7.fhir.uv.extensions.r4` 5.2.0 und `hl7.fhir.uv.ips` 2.0.1 aktualisiert.

#### Modul Person

* **Added:** Ein AllergyIntolerance-Profil und zugehörige Elemente im logischen Modell zur Abbildung patientenbezogener Allergien und Unverträglichkeiten einschließlich auslösendem Stoff, klinischem Status, Kritikalität und beobachteten Reaktionen ergänzt.
* **Added:** Das Patient-Profil enthält nun die FHIR-Core-Extensions `patient-birthPlace`, `patient-citizenship` und `patient-nationality`, um Geburtsort, Staatsangehörigkeit und Nationalität im Modul Person abzubilden. Siehe: [#86](https://github.com/medizininformatik-initiative/kerndatensatz-basis/issues/86)
* **Added:** Die Hinweise zu Patient-Adressen empfehlen nun die aus `AddressDeBasis` geerbte Extension `countryCode` für ISO-3166-1-Alpha-2-Ländercodes und richten damit die codierte Länderangabe an HL7 Europe Address (EU) aus. Siehe: [#20](https://github.com/medizininformatik-initiative/kerndatensatz-basis/issues/20)
* **Added:** Das Patient-Profil unterstützt nun über die Extension [`individual-recordedSexOrGender`](https://hl7.org/fhir/extensions/StructureDefinition-individual-recordedSexOrGender.html) wiederholbare dokumentierte Geschlechtsangaben getrennt vom administrativen Geschlecht. Siehe: [#81](https://github.com/medizininformatik-initiative/kerndatensatz-basis/issues/81)
* **Removed:** `ProbandIn` und dessen Unterelemente aus dem logischen Modell Person entfernt. Siehe: [#90](https://github.com/medizininformatik-initiative/kerndatensatz-basis/issues/90)

#### Modul Diagnose

* **Added:** Das Element `Condition.bodySite` enthält nun die FHIR-Core-Extension `http://hl7.org/fhir/StructureDefinition/bodySite`, um eine detaillierte anatomische Referenz, z.B. auf eine `BodyStructure`, zusätzlich zur codierten Körperstelle abzubilden. Siehe: [#85](https://github.com/medizininformatik-initiative/kerndatensatz-basis/issues/85)
* **Changed:** Die Mappings für `Condition.onset[x]` und `Condition.abatement[x]` wurden klargestellt; Erkrankungsbeginn und Erkrankungsende werden nun getrennt abgebildet und mit ISiK harmonisiert. `Period` bleibt aus Gründen der Rückwärtskompatibilität zulässig, SOLL aber NICHT verwendet werden. Siehe: [#83](https://github.com/medizininformatik-initiative/kerndatensatz-basis/issues/83)
* **Changed:** Beziehung zwischen Diagnosen und Kontakten im Diagnose-UML angepasst, sodass der Abteilungskontakt als derzeit empfohlene Kontaktebene dargestellt wird und andere Kontaktebenen weiterhin möglich bleiben.

#### Modul Fall

* **Changed:** UML-Modell des Moduls Fall angepasst, sodass die organisatorische Zuordnung zwischen Versorgungsstellen und Abteilungen als optionale n:m-Beziehung dargestellt wird.
* **Added:** Leitlinien für ambulante Encounter zur dreistufigen Encounter-Hierarchie, zu `Encounter.partOf`-Beziehungen und zum Umgang mit nicht verfügbaren Zeitstempeln ergänzt. Siehe: [#74](https://github.com/medizininformatik-initiative/kerndatensatz-basis/issues/74)
* **Changed:** Encounter-Hierarchieabbildung erweitert, um zu veranschaulichen, wie Encounter auf jeder Hierarchieebene denselben Account referenzieren und einen gemeinsamen Abrechnungskontext teilen können. Siehe: [#73](https://github.com/medizininformatik-initiative/kerndatensatz-basis/issues/73)

#### Modul Prozedur

* **Changed:** Beziehung zwischen Prozeduren und Kontakten im Prozedur-UML angepasst, sodass der Abteilungskontakt als derzeit empfohlener Kontaktkontext dargestellt wird und andere Kontaktebenen weiterhin möglich bleiben.
* **Added:** Das Element `Procedure.bodySite` enthält nun die FHIR-Core-Extension `http://hl7.org/fhir/StructureDefinition/bodySite`, um eine detaillierte anatomische Referenz, z.B. auf eine `BodyStructure`, zusätzlich zur codierten Körperstelle abzubilden. Siehe: [#85](https://github.com/medizininformatik-initiative/kerndatensatz-basis/issues/85)

#### Terminologie-Updates

* **Added:** Das neue [MII ValueSet Person Recorded Sex or Gender SNOMED](ValueSet-mii-vs-person-recordedsexorgender-snomed.md) ist mit der Bindungsstärke `preferred` an `Patient.extension:recordedSexOrGender.extension:value` gebunden. Es enthält SNOMED-CT-Befunde zum biologischen Geschlecht und den Qualifier-Wert `Unknown`.
* **Changed:** Ressourcen verwenden SNOMED CT-Version `http://snomed.info/sct/900000000000207008/version/20260701` (Juli 2026) modulübergreifend, um stabile [ValueSet-Expansion](http://hl7.org/fhir/R4/valueset.html#expansion) zu gewährleisten

-------

### Version 2026.0.1

**Datum:** 2026-07-20

#### Dokumentation

* **Added:** Eine Liste der Konformitätsanforderungen ist in der englischen Version der [Conformance Seite](conformance.md) verfügbar
* **Added:** CapabilityStatements dokumentieren nun Beispiel-FHIR-Suchanfragen für unterstützte SearchParameters
* **Added:** LogicalModel-Seiten enthalten nun Mapping-Tabellen zu den entsprechenden FHIR-Zielstrukturen
* **Added:** CRMI-Abhängigkeit auf STU-2-Release 2.0.0
* **Added:** Metadaten-Dokumentation zu CRMI-basierten Artefaktmetadaten, Versionierung und Package-Provenance, Manifest-Parametern und zum Bezug zu FAIR Data Maturity Indicators ergänzt
* **Added:** Die ImplementationGuide-Dokumentation beschreibt nun IG-Parametereinstellungen und Expansionsparameter
* **Changed:** Must Support-Flags werden nun einheitlich auf relevante Unterelemente in allen Profilen angewendet, und die Dokumentation zu [Must Support](must-support.md) beschreibt, wie komplexe Elemente und ihre markierten Unterelemente konkrete Erwartungen an die Server- und Client-Unterstützung definieren.
* **Changed:** Deutsche Formulierungen der Konformitätsverben verbessert und englische sowie deutsche Seiten für eine konsistente Verwendung der RFC-2119-Konformitätsverben abgeglichen.
* **Changed:** Die Versionierungsdokumentation erläutert das Calendar-Versioning-Schema nun als SemVer-kompatibles Format `YYYY.MINOR.PATCH[-label]` und dokumentiert, dass veröffentlichte Artefakte dieselbe Version wie das IG-Package verwenden

#### Terminologie-Updates

* **Added:** ICD-10-GM 2026, OPS 2026 und Alpha-ID 2026 Versionen zu den jeweiligen ValueSet-Definitionen für die Module Diagnose und Prozedur hinzugefügt [#67](https://github.com/medizininformatik-initiative/kerndatensatz-basis/issues/67), [#66](https://github.com/medizininformatik-initiative/kerndatensatz-basis/issues/66)

#### Modul Person

* **Added:** Profil [Patient Pseudonymisiert](StructureDefinition-mii-pr-person-patient-pseudonymisiert.md): Optionaler `type.coding`-Slice `mr` (`http://terminology.hl7.org/CodeSystem/v2-0203|MR`) zu `PseudonymisierterIdentifier` hinzugefügt. Wenn das Pseudonym eine Medical Record Number ersetzt, SOLL dieser Code gesetzt werden, um die standortunabhängige Auffindbarkeit des Identifiers zu ermöglichen. Siehe: [#63](https://github.com/medizininformatik-initiative/kerndatensatz-basis/issues/63)

#### Modul Fall

* **Added:** Verwendung von `Encounter.location` in der Dokumentation erläutert. Siehe: [#62](https://github.com/medizininformatik-initiative/kerndatensatzmodul-fall/issues/62)
* **Added:** Dokumentiert, dass Server den Modifier `account:identifier` unterstützen SOLLEN, um die Suche aller zu einem Abrechnungsfall gehörenden Encounter anhand der Fallnummer zu ermöglichen. Siehe: [#68](https://github.com/medizininformatik-initiative/kerndatensatz-basis/issues/68)
* **Removed:** Selbst veröffentlichte R5-Backport-Extensions für geplante Encounter-Start- und Enddaten (zuvor `mii-ex-fall-planned-start-date` und `mii-ex-fall-planned-end-date`). Diese Extensions werden nun durch die offizielle `hl7.fhir.uv.xver-r5.r4`-Dependency bereitgestellt

-------

### Version 2026.0.0

**Datum:** 13.12.2025

#### Modulkonsolidierung

* **Konsolidierter Implementierungsleitfaden:** Die vier Basismodule (Person, Fall, Diagnose und Prozedur) wurden zu einem Implementierungsleitfaden zusammengeführt
* **Package-ID:** `de.medizininformatikinitiative.kerndatensatz.base`

#### Terminologie-Updates

* **Changed:** Ressourcen verwenden SNOMED CT-Version `http://snomed.info/sct/900000000000207008/version/20250701` (Juli 2025) modulübergreifend, um stabile [ValueSet-Expansion](http://hl7.org/fhir/R4/valueset.html#expansion) zu gewährleisten

#### Beispielkonsolidierung

* **Einheitliches Testdaten-Bundle:** Beispielressourcen wurden in einem umfassenden Testdaten-Bundle zusammengeführt
* **Modulübergreifende Beispiele:** Beispiele demonstrieren nun Beziehungen und Referenzen über alle vier Module hinweg

#### Modul Diagnose

* **Changed:** Aktualisierte Anleitung zur Verwendung von Condition.encounter zur Ausrichtung an gematik ISiK-Empfehlungen (Informationstechnische Systeme in Krankenhäusern)
* **Changed:** Condition.encounter SOLL nun auf einen Encounter der Ebene "Abteilungskontakt" referenzieren
* **Hinweis:** Dies stellt eine Änderung gegenüber vorherigen Versionen dar, in denen Encounter.diagnosis die primäre Verknüpfungsmethode war

#### Modul Fall

* **Changed:** Aktualisierte Anleitung zum Abrechnungsfallkontext und Account-Referenzen basierend auf der gematik ISiK-Spezifikation
* **Changed:** Erweiterte Dokumentation zur Unterscheidung zwischen Aufnahmenummer und Fallnummer
* **Changed:** Klargestellt, dass die Fallnummer den Abrechnungsfall (Account) identifiziert und als logische Referenz in `Encounter.account.identifier` angegeben werden soll
* **Changed:** Jeder Encounter SOLL seine eigene eindeutige Aufnahmenummer in `Encounter.identifier:Aufnahmenummer` haben

#### Modul Prozedur

* **Changed:** Anleitung hinzugefügt mit Empfehlung zur Verwendung von `Procedure.encounter` zur Etablierung des Kontaktkontexts, abgestimmt mit den Empfehlungen des Diagnose-Moduls

#### Modul Person

* **Added:** ValueSet MII VS Person ICD-10-WHO veröffentlicht unter MII-Canonical URL für Todesursachen-Codierung

-------

### Version 2025.0.1

#### Modul Person

**Datum:** 08.10.2025

* **Added**: Profil [Patient Pseudonymisiert](StructureDefinition-mii-pr-person-patient-pseudonymisiert.md) enthält nun einen optionalen Identifikator für maskierte Krankenversicherungsnummer unter `Patient.identifier`
* **Changed**: ValueSet MII_VS_Person_ICD10WHO wurde als redundant [zurückgezogen](http://hl7.org/fhir/R4/codesystem-publication-status.html#publication-status-retired). Das ICD-10-WHO CodeSystem referenziert bereits ein implizites ICD-10-WHO ValueSet über `CodeSystem.valueSet`. Siehe: [#86](https://github.com/medizininformatik-initiative/kerndatensatzmodul-person/issues/86)
* **Changed**: Abhängigkeit aktualisiert auf [de.basisprofil.r4 1.5.4](https://simplifier.net/packages/de.basisprofil.r4/1.5.4). Diese Version der FHIR-Basisprofile enthält eine Korrektur für die kvid-2-Invariante, die auf `Patient.identifier:versichertenId.type` im Patient-Profil angewendet wird

#### Modul Fall

**Datum:** 28.10.2025

* **Changed**: `Encounter.location` erlaubt nun die Angabe früherer Behandlungsorte. Siehe: [#79](https://github.com/medizininformatik-initiative/kerndatensatzmodul-fall/issues/79)

#### Modul Diagnose

**Datum:** 20.10.2025

* **Added**: `Condition.onsetAge` - Der Datentyp `Age` kann nun unter `Condition.onset[x]` verwendet werden. Siehe: [#78](https://github.com/medizininformatik-initiative/kerndatensatzmodul-diagnose/issues/78)
* **Changed**: `Condition.bodySite` - Kardinalität des SNOMED-Coding-Slices von 1..1 auf 0..1 geändert. Siehe: [#75](https://github.com/medizininformatik-initiative/kerndatensatzmodul-diagnose/issues/75)
* **Added**: Neue ValueSets und Bindings für ICD-10-GM (Canonical URL: `https://www.medizininformatik-initiative.de/fhir/core/modul-diagnose/ValueSet/mii-vs-diagnose-icd10gm`) und AlphaID (Canonical URL: `https://www.medizininformatik-initiative.de/fhir/core/modul-diagnose/ValueSet/mii-vs-diagnose-alphaid`), die über den MII-Terminologieserver (https://www.ontoserver.mii-termserv.de/) expandiert werden können, was erweiterte Validierung ermöglicht
* **Changed**: CapabilityStatement enthält nun Anforderungsdokumentation für Suchparameter `_count` und `_summary`

#### Modul Prozedur

**Datum:** 22.10.2025

* **Added**: `Procedure.bodySite` - Enthält nun optionalen SNOMED-Coding-Slice, übernimmt die Modellierung aus dem `Condition.bodySite` des Diagnose-Moduls
* **Added**: ValueSet und Binding für OPS (Canonical URL: `https://www.medizininformatik-initiative.de/fhir/core/modul-prozedur/ValueSet/mii-vs-prozedur-ops`). Dieses kann über den MII-Terminologieserver (https://www.ontoserver.mii-termserv.de/) expandiert werden, was erweiterte Validierung ermöglicht
* **Added**: CapabilityStatement enthält nun Anforderungsdokumentation für Suchparameter `_count` und `_summary`

-------

### Version 2025.0.0

#### Modul Person

**Datum:** 06.12.2024

* **Changed**: Abhängigkeit von de.basisprofil.r4 auf Version 1.5.0 aktualisiert 
* Dies ändert das [Patient](StructureDefinition-mii-pr-person-patient.md)-Profil im Element `Patient.identifier`: Gesetzliche und private Krankenversicherungsnummern verwenden nun ein einheitliches Identifikatorprofil [IdentifierKvid10](https://simplifier.net/packages/de.basisprofil.r4/1.5.0/files/2461154). `Patient.identifier.type` MUSS für Krankenversicherungsnummern auf `KVZ10` geändert werden. Die zuvor verwendeten Codes `GKV` und `PKV` für `Patient.identifier.type` haben den Status `retired` (siehe [CodeSystem IdentifierTypeDeBasis](https://simplifier.net/packages/de.basisprofil.r4/1.5.0/files/2461165)). Patient-Ressourcen aus Version 2024 bleiben gültig, SOLLEN aber auf den neuen Identifikator umstellen
 
* **Removed**: Das ResearchSubject-Profil wurde [zurückgezogen](http://hl7.org/fhir/R4/codesystem-publication-status.html#publication-status-retired). Ab Version 2025.0.0 wird dieses Profil im Studien-Modul veröffentlicht und entwickelt. Implementierungen SOLLEN auf die Modellierung aus dem Studien-Modul umstellen
* **Removed**: CodeSystem ICD-10-WHO v2019 und v2016 wurden entfernt. Diese können nun über den MII-Terminologieservice (SU-TermServ) bezogen werden: https://www.ontoserver.mii-termserv.de/
* **Removed**: Suchparameter aus diesem Modul wurden entfernt. SearchParameter-Ressourcen werden nun zentral im Meta-Modul verwaltet
* **Changed**: Profile enthalten zusätzliche Beschreibungen und Übersetzungen für Implementierer und das Forschungsdatenportal Gesundheit (FDPG)

#### Modul Fall

**Datum:** 10.12.2024

* **Changed**: Abhängigkeit von de.basisprofil.r4 auf Version 1.5.0 aktualisiert. Diese Änderung hat keine Auswirkungen auf Implementierungen dieses Moduls
* **Changed**: Profile enthalten zusätzliche Beschreibungen und Übersetzungen für Implementierer und das Forschungsdatenportal Gesundheit (FDPG)
* **Removed**: Suchparameter aus diesem Modul entfernt. SearchParameter-Ressourcen werden nun zentral im Meta-Modul verwaltet
* **Changed**: Kardinalität von `Encounter.period` im [Encounter](StructureDefinition-mii-pr-fall-kontakt-gesundheitseinrichtung.md)-Profil von 1..1 auf 0..1, um geplante Behandlungsfälle darzustellen, bei denen der tatsächliche Zeitraum noch unbekannt ist. Siehe: [#56](https://github.com/medizininformatik-initiative/kerndatensatzmodul-fall/issues/56)
* **Added**: Constraints prüfen nun das Vorhandensein von Start- und Endzeiten (`Encounter.period`) abhängig vom Status eines Falls
* **Added**: Erweiterung des Encounter-Profils mit zwei Extensions für geplante Start- und Enddaten in `Encounter.extension`
* **Fixed**: Korrektur des ValueSet-Bindings auf Element `Encounter.serviceType.coding:ErweiterterFachabteilungsschluessel` zu [http://fhir.de/ValueSet/dkgev/Fachabteilungsschluessel-erweitert](https://simplifier.net/packages/de.basisprofil.r4/1.4.0/files/656779)
* **Changed**: Must-Support FHIR-Datenelemente im Encounter-Profil enthalten nun erweiterte Beschreibungen unter 'Short description' und 'Definition'
* **Added**: `Encounter.diagnosis.use` hat nun ValueSet-Binding zu `https://www.medizininformatik-initiative.de/fhir/core/modul-fall/ValueSet/mii-vs-fall-diagnosis-use`
* **Changed**: In `Encounter.location`-Slices für Zimmer, Bett, Station - Kardinalität der Elemente `Encounter.location.location.identifier` und `Encounter.location.location.display` von 1..1 auf 0..1 geändert
* **Removed**: MustSupport-Labels von `Encounter.location` und `Encounter.serviceProvider` entfernt

#### Modul Diagnose

**Datum:** 09.12.2024

* **Changed**: Abhängigkeit von de.basisprofil.r4 auf [Version 1.5.0](https://simplifier.net/packages/de.basisprofil.r4/1.5.0) aktualisiert. Diese Änderung hat keine Auswirkungen auf Implementierungen dieses Moduls
* **Removed**: `Condition.code` und `Condition.bodySite` ICD-O-3-Slices entfernt. Diese werden nun vom Onkologie-Modul definiert
* **Changed**: Profile enthalten zusätzliche Beschreibungen und Übersetzungen für Implementierer und das Forschungsdatenportal Gesundheit (FDPG)
* **Removed**: Suchparameter aus diesem Modul entfernt. SearchParameter-Ressourcen werden nun zentral im Meta-Modul verwaltet
* **Changed**: Ressourcen verwenden SNOMED CT-Version `http://snomed.info/sct/900000000000207008/version/20240701` modulübergreifend, um stabile [ValueSet-Expansion](http://hl7.org/fhir/R4/valueset.html#expansion) zu gewährleisten
* **Added**: `Condition.verificationStatus` hat nun MustSupport-Label. Siehe: [#64](https://github.com/medizininformatik-initiative/kerndatensatzmodul-diagnose/issues/64)

#### Modul Prozedur

**Datum:** 09.12.2024

* **Changed**: Abhängigkeit von de.basisprofil.r4 auf [Version 1.5.0](https://simplifier.net/packages/de.basisprofil.r4/1.5.0) aktualisiert. Diese Änderung hat keine Auswirkungen auf Implementierungen dieses Moduls
* **Changed**: Profile enthalten zusätzliche Beschreibungen und Übersetzungen für Implementierer und das Forschungsdatenportal Gesundheit (FDPG)
* **Removed**: Suchparameter aus diesem Modul entfernt. SearchParameter-Ressourcen werden nun zentral im Meta-Modul verwaltet
* **Removed**: CodeSystem-Ressourcen für Operationen- und Prozedurenschlüssel (OPS) wurden entfernt. Diese können nun über den MII-Terminologieservice (SU-TermServ) bezogen werden: https://www.ontoserver.mii-termserv.de/
* **Changed**: Ressourcen verwenden SNOMED CT-Version `http://snomed.info/sct/900000000000207008/version/20240701` modulübergreifend, um stabile [ValueSet-Expansion](http://hl7.org/fhir/R4/valueset.html#expansion) zu gewährleisten

-------

### Version 2024.0.1

#### Modul Fall

**Datum:** 17.04.2024

* **Fixed**: Korrektur der Versionsparameter in Konformitätsressourcen. Im zuvor veröffentlichten Paket stimmte `StructureDefinition.version` nicht einheitlich mit der Paketversion überein. Siehe: [#51](https://github.com/medizininformatik-initiative/kerndatensatzmodul-fall/issues/51)

-------

### Version 2024.0.0

Alle Module haben [Calendar Versioning (CalVer)](https://calver.org/) mit dem Schema YYYY.MINOR.PATCH übernommen und damit einen jährlichen Release-Zyklus etabliert.

#### Modul Person

**Datum:** 16.04.2024

* **Changed**: Versionierungsschema auf [Calendar Versioning (CalVer)](https://calver.org/) mit Schema YYYY.MINOR.PATCH umgestellt
* **Changed**: Benennung von Konformitätsressourcen und Beispielinstanzen folgt einheitlichen [MII-Namenskonventionen](https://github.com/medizininformatik-initiative/kerndatensatz-meta/wiki/Namenskonventionen-f%C3%BCr-FHIR%E2%80%90Ressourcen-in-der-MII)
* **Changed**: Ressourcen verwenden SNOMED CT-Version `http://snomed.info/sct/900000000000207008/version/20230731` modulübergreifend, um stabile ValueSet-Expansion zu gewährleisten
* **Changed**: Im [Patient](StructureDefinition-mii-pr-person-patient.md)-Profil wurden alle min 1.. Kardinalitäten entfernt
* **Added**: Profil [Patient Pseudonymisiert](StructureDefinition-mii-pr-person-patient-pseudonymisiert.md) ist neu seit Version 1.0. Im Vergleich zu zuvor veröffentlichten Versionen wurden alle 0..0 Kardinalitäten entfernt. Außerdem werden vom Profil keine Pseudonymisierungsregeln mehr vorgeschrieben. Die genauen Pseudonymisierungsregeln innerhalb der Medizininformatik-Initiative werden noch entwickelt und können in einer späteren Version des Profils angewendet werden. Folglich wurden die folgenden Invarianten entfernt: 
* 'GeburtsdatumRundenAufQuartal' auf **Patient.birthDate**
* 'TodesdatumKeineZeitangabe' auf **Patient.deceasedDateTime**
* 'PostleitzahlEinschraenkung' auf **Patient.address.postalCode**
 
* **Added**: Neues Profil [Todesursache](StructureDefinition-mii-pr-person-todesursache.md) zur Darstellung der Todesursache mit ICD-10-WHO
* **Changed**: Datentypen im logischen Modell wurden angepasst, um den Datentypen der Elemente im FHIR-Profil zu entsprechen, auf die sie gemappt sind

#### Modul Fall

**Datum:** 28.03.2024

* **Changed**: Versionierungsschema auf [Calendar Versioning (CalVer)](https://calver.org/) umgestellt
* **Changed**: Benennung von Konformitätsressourcen und Beispielinstanzen folgt einheitlichen MII-Namenskonventionen
* **Changed**: Anforderungsdokumentation verwendet nun Schlüsselwörter gemäß [RFC-2119](https://datatracker.ietf.org/doc/html/rfc2119)
* **Changed**: Abhängigkeit von [Version 0.9.13](https://simplifier.net/packages/de.basisprofil.r4/0.9.13) auf [Version 1.4.0](https://simplifier.net/packages/de.basisprofil.r4/1.4.0) der FHIR-Basisprofile geändert
* **Breaking Changes** beim Wechsel von Version 1.0 auf Version 2.0 (2024.0.0): 
* Aufnahmegrund wurde in Version 1.0 unter `Encounter.reasonCode` spezifiziert. Wird nun über [Extension aus German FHIR Base Profiles](https://simplifier.net/packages/de.basisprofil.r4/1.4.0/files/656695) im Element `Encounter.extension:Aufnahmegrund` erfasst
* ValueSet-Binding auf Element `Encounter.identifier.type` für Aufnahmenummer erweitert mit Code [v2-0203#VN](https://simplifier.net/resolve?scope=hl7.fhir.r4.core@4.0.1&filepath=package/CodeSystem-v2-0203.json)
* Unter `Encounter.location` gibt es nun eine Spezifikation, wie Informationen über Zimmer-, Bett- und Stationsstandorte OPTIONAL dargestellt werden können
* In Version 1.0 war `Encounter.diagnosis.use` bei der Angabe einer Diagnose OPTIONAL. Neu in dieser Version ist die Aufteilung von `Encounter.diagnosis.use.coding` in Diagnosetyp und Diagnoseuntertyp, von denen mindestens einer vorhanden sein MUSS
* In Version 1.0 enthielt `Encounter.serviceType` nur eine Spezifikation für den Fachabteilungsschlüssel. Dies wurde in dieser Version um den erweiterten Fachabteilungsschlüssel erweitert
 

#### Modul Diagnose

**Datum:** 16.04.2024

* **Changed**: Versionierungsschema auf [Calendar Versioning (CalVer)](https://calver.org/) umgestellt
* **Changed**: Benennung von Konformitätsressourcen und Beispielinstanzen folgt einheitlichen MII-Namenskonventionen
* **Changed**: Ressourcen verwenden SNOMED CT-Version `http://snomed.info/sct/900000000000207008/version/20230731` für stabile ValueSet-Expansion
* **Changed**: Anforderungsdokumentation verwendet nun Schlüsselwörter gemäß [RFC-2119](https://datatracker.ietf.org/doc/html/rfc2119)
* **Changed**: Abhängigkeit von [Version 0.9.13](https://simplifier.net/packages/de.basisprofil.r4/0.9.13) auf [Version 1.4.0](https://simplifier.net/packages/de.basisprofil.r4/1.4.0) der FHIR-Basisprofile geändert
* **Breaking Changes** beim Wechsel von Version 1.0 auf Version 2.0 (2024.0.0): 
* Für doppelt/mehrfach kodierte ICD-Codes MUSS die Darstellung der Code-Komponenten über separate Condition-Ressourcen erfolgen
* Die Verknüpfung von Condition-Ressourcen MUSS über die [Extension: Condition Related](http://hl7.org/fhir/StructureDefinition/condition-related) erfolgen
* Jeder vorhandene Mehrfachkodierungskennzeichen (`*`, `†`, `!`) MUSS vom ICD-Code getrennt und in der [Extension: Multiple Coding Indicator for ICD-10-GM](https://simplifier.net/packages/de.basisprofil.r4/1.4.0/files/656614) erfasst werden
* Die kanonische URL für das ICD-10-GM CodeSystem wurde von `http://fhir.de/CodeSystem/dimdi/icd-10-gm` auf `http://fhir.de/CodeSystem/bfarm/icd-10-gm` geändert. Die aktuelle kanonische URL MUSS im Element `Condition.code.coding.system` für ICD-10-GM-Codes verwendet werden
 
* **Added**: Im [Diagnose](StructureDefinition-mii-pr-diagnose-condition.md)-Profil wurden die Elemente `Condition.code.coding` und `Condition.bodySite.coding` jeweils mit einem OPTIONALEN Slice für ICD-O-3 erweitert
* **Added**: Im Profil unter `Condition.extension('http://hl7.org/fhir/StructureDefinition/condition-assertedDate')` gibt es nun eine Extension zur Angabe des Feststellungsdatums einer Diagnose
* **Added**: Im Profil unter `Condition.onsetPeriod.(start|end).extension` gibt es nun OPTIONAL eine Spezifikation zur Angabe der Lebensphase als Code via Extension, ab der ein Patient eine Erkrankung hat oder nicht mehr hat
* **Added**: Modul wurde um SearchParameter-Ressourcen erweitert, die die Suche nach ICD-10-GM-Codes in Kombination mit Mehrfachkodierungskennzeichen, Lateralität und diagnostischer Sicherheit ermöglichen

#### Modul Prozedur

**Datum:** 16.04.2024

* **Changed**: Versionierungsschema auf [Calendar Versioning (CalVer)](https://calver.org/) umgestellt
* **Changed**: Benennung von Konformitätsressourcen und Beispielinstanzen folgt einheitlichen MII-Namenskonventionen
* **Changed**: Ressourcen verwenden SNOMED CT-Version `http://snomed.info/sct/900000000000207008/version/20230731` für stabile ValueSet-Expansion
* **Changed**: Anforderungsdokumentation verwendet nun Schlüsselwörter gemäß [RFC-2119](https://datatracker.ietf.org/doc/html/rfc2119)
* **Changed**: Abhängigkeit von [Version 0.9.13](https://simplifier.net/packages/de.basisprofil.r4/0.9.13) auf [Version 1.4.0](https://simplifier.net/packages/de.basisprofil.r4/1.4.0) der FHIR-Basisprofile geändert
* **Breaking Changes** beim Wechsel von Version 1.0 auf Version 2.0 (2024.0.0): 
* Die kanonische URL für das OPS CodeSystem wurde von `http://fhir.de/CodeSystem/dimdi/ops` auf `http://fhir.de/CodeSystem/bfarm/ops` geändert. Die aktuelle kanonische URL MUSS im Element `Procedure.code.coding.system` für OPS-Codes verwendet werden
 
* **Breaking Change**: Im ValueSet MII_VS_Prozedur_OpsKategorien_SNOMEDCT wurde ein inaktiver SNOMED-Code `103693007 |Diagnostic procedure (procedure)|` durch `165197003 |Diagnostic assessment (procedure)|` ersetzt. Das ValueSet wird auf `Procedure.category.coding` verwendet. Falls der inaktive Code zuvor in Version 1.0 dieses Moduls implementiert wurde, MUSS dieser Code beim Wechsel auf Version 2.0 (2024.0.0) des Prozedur-Moduls geändert werden

-------

### Versionierungsschema

Ab Version 2024.0.0 verwenden alle Module [Calendar Versioning (CalVer)](https://calver.org/) mit dem Schema YYYY.MINOR.PATCH:

* **YYYY** (Jahresversion): Gibt das Jahr an, in dem das Kerndatensatzmodul angewendet wird
* **MINOR**: Veröffentlicht bei Einführung neuer Features, Erweiterungen oder wesentlicher Änderungen
* **PATCH**: Enthält Fehlerbehebungen oder textliche Korrekturen

Dies etabliert einen jährlichen Release-Zyklus, der über alle Basismodule hinweg abgestimmt ist.

