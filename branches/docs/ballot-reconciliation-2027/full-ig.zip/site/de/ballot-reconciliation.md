# Ballot-Kommentierung 2027.0.0-ballot - MII Implementation Guide Core Dataset Base v2027.0.0-ballot

* [**Inhaltsverzeichnis**](toc.md)
* **Ballot-Kommentierung 2027.0.0-ballot**

## Ballot-Kommentierung 2027.0.0-ballot

Diese Seite ist ein **Arbeitsdokument** für die Bearbeitung der Ballot-Kommentare zur Version `2027.0.0-ballot` des MII Kerndatensatz Basis. Sie listet die offenen Tickets aus dem Ballot von HL7 Deutschland ([Jira-Abfrage](https://hl7germany.atlassian.net/issues/?jql=project%20%3D%20HDB%20AND%20created%20%3E%3D%20-200d%20AND%20%22Project%5BDropdown%5D%22%20in%20%28%22MII%20%E2%80%93%20Modul%20Basis%20%28Person%2C%20Fall%2C%20Diagnose%20%26%20Prozedur%29%22%29%20ORDER%20BY%20created%20DESC)) nach Kategorie gruppiert mit einem **vorgeschlagenen** Vorgehen auf.

#### Legende

| | |
| :--- | :--- |
| **Vorschlag: annehmen** | Vorschlag, die Änderung für`2027.0.0`umzusetzen; Bestätigung in der Sitzung. |
| **Vorschlag: annehmen (Doku)** | Vorschlag, nur Dokumentation oder Implementierungshinweise zu ändern, keine Änderung an Artefakten; Bestätigung in der Sitzung. |
| **Diskussion** | Noch kein vorgeschlagenes Vorgehen; wird in der Sitzung besprochen. |
| **Antwort geplant** | Rückfrage oder organisationsübergreifendes Thema; eine Antwort in Jira ist geplant (Entwurf oder noch benötigte Informationen sind angegeben), keine Änderung in diesem Leitfaden. |
| **Vorschlag: nach Meta verschieben** | Betrifft das Modul Meta (`kerndatensatz-meta`); Vorschlag, das Ticket dorthin zu verschieben. |

**Breaking** = **ja**, wenn Implementierungen, die zur vorherigen Version (`2026.0.x`) konform sind, nach der Änderung nicht mehr konform sind. Änderungen an Artefakten, die erst mit `2027.0.0-ballot` eingeführt wurden (z. B. das AllergyIntolerance-Profil), sind nicht breaking.

-------

### A. Vorschlag: annehmen – Profiländerungen

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| [HDB-1075](https://hl7germany.atlassian.net/browse/HDB-1075) | Extension Lebensphase in Datentyp "Range" | Die Extension Lebensphase wird von`Condition.onsetAge`/`abatementAge`nach`onsetRange`/`abatementRange`verschoben. Der Kontext der Extension in`de.basisprofil.r4`1.6.0 erlaubt nur`dateTime`,`Period.start`,`Period.end`und`Range`; die aktuelle Platzierung ist daher ungültig. Das Mapping im logischen Modell wird entsprechend angepasst. | Vorschlag: annehmen | **ja** |
| [HDB-1069](https://hl7germany.atlassian.net/browse/HDB-1069) | Constraint "pat-cnt-2or3-char" in Adress.country | `pat-cnt-2or3-char`prüft künftig die Extension`countryCode`(`iso21090-codedString`) statt`Address.country`, sodass`country`auch andere Werte (z. B. DEÜV) enthalten darf. | Vorschlag: annehmen | nein |
| [HDB-935](https://hl7germany.atlassian.net/browse/HDB-935) | country constraints noch nicht angepasst? | Wird zusammen mit HDB-1069 umgesetzt. | Vorschlag: annehmen | nein |
| [HDB-1124](https://hl7germany.atlassian.net/browse/HDB-1124) | Binding Strengh in Extension individual-recordedSexOrGender anpassen | Die Binding-Stärke von`Patient.extension:recordedSexOrGender.extension:value.valueCodeableConcept`an`MII_VS_Person_recordedSexOrGender_SNOMED`wird von**preferred**auf**extensible**geändert. Zum Hintergrund des Bindings siehe HDB-1068. | Vorschlag: annehmen | nein (neu im Ballot) |
| [HDB-1067](https://hl7germany.atlassian.net/browse/HDB-1067) | Verwendung der Extension "Patient Sex Parameter For Clinical Use" | `patient-sexParameterForClinicalUse`(hl7.fhir.uv.extensions.r4 5.2.0) wird als optionale Extension in das Patient-Profil aufgenommen. | Vorschlag: annehmen | nein |
| [HDB-1073](https://hl7germany.atlassian.net/browse/HDB-1073) | Wahl der Valuesets in AllergyIntolerance.code und reaction.manifestation | Die IPS-Bindings (derzeit**preferred**) werden durch die KBV-ValueSets ersetzt, abgestimmt mit der anstehenden ISiK-Änderung (ISiK`main-stufe-6`; ISiK Basis 6.0.0 selbst nutzt noch die Beispiel-Bindings des FHIR-Core):`AllergyIntolerance.code.coding:snomed-ct`aus`https://fhir.kbv.de/ValueSet/KBV_VS_AllergyIntolerance_Substance_SNOMED_CT|1.0.0`(**extensible**) und`AllergyIntolerance.reaction.manifestation.coding:snomed-ct`aus`https://fhir.kbv.de/ValueSet/KBV_VS_AllergyIntolerance_Manifestation_SNOMED_CT|1.0.0`(**extensible**), übereinstimmend mit dem ISiK-Entwicklungsstand. Paket identifiziert: Beide ValueSets sind in`kbv.all.terminology.allergyintolerance#1.0.0`enthalten (BfArM, geschützt: Download erfordert die Annahme der Nutzungsbedingungen und ein Token); die Einrichtung der Validierung steht noch aus. | Vorschlag: annehmen | nein (neu im Ballot) |
| [HDB-1019](https://hl7germany.atlassian.net/browse/HDB-1019) | AllergyIntolerance.code.coding:snomed-ct | Angleichung an ISiK Basis 6.0.0:`AllergyIntolerance.code.coding`1..* mit einem**verpflichtenden**Slice`coding:snomed-ct`1..1 (Binding wie in HDB-1073). Allergien, die nur in anderen Systemen kodiert sind, wären dann nicht mehr konform. Dies ist eine inhaltliche Grundsatzentscheidung der MII und muss in der Sitzung ausdrücklich entschieden werden. | Vorschlag: annehmen | nein gegenüber`2026.0.x`(neu im Ballot), aber strenger als das veröffentlichte Ballot-Profil |
| [HDB-1072](https://hl7germany.atlassian.net/browse/HDB-1072) | Verwendung der Lebensphase Extension in AllergyIntolerance | Die Extension Lebensphase wird an`AllergyIntolerance.onsetRange`und an`AllergyIntolerance.extension:abatement.valueRange`erlaubt (die Extension`allergyintolerance-abatement`erlaubt`Range`), konsistent mit HDB-1075. | Vorschlag: annehmen | nein (neu im Ballot) |
| [HDB-1074](https://hl7germany.atlassian.net/browse/HDB-1074) | BodyStructure Profile aus EU Core referenzieren | Empfehlung: Das EU-Profil`http://hl7.eu/fhir/base/StructureDefinition/bodyStructure-eu-core`(`hl7.fhir.eu.base`2.0.1, neue Abhängigkeit) wird**direkt**als Ziel von`Condition.bodySite.extension:bodySite.valueReference`und`Procedure.bodySite.extension:bodySite.valueReference`referenziert. Ein eigenes abgeleitetes MII-Profil ist nur nötig, wenn MII-spezifische Einschränkungen erforderlich sind. | Vorschlag: annehmen | nein (neu im Ballot) |

### B. Vorschlag: annehmen – Terminologie-Ergänzungen

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| [HDB-1068](https://hl7germany.atlassian.net/browse/HDB-1068) | Wahl des Valueset in Extension "Recorded Sex or Gender" | Hintergrund: Die Upstream-Extension`individual-recordedSexOrGender`hat an`value`nur ein**example**-Binding (`administrative-gender`). Das MII-Patient-Profil bindet`value`an das SNOMED-CT-ValueSet`MII_VS_Person_recordedSexOrGender_SNOMED`mit der Stärke**preferred**(**extensible**vorgeschlagen in HDB-1124). Die Extension deckt dokumentierte Geschlechtsangaben allgemein ab; der primäre MII-Anwendungsfall ist das bei Geburt zugewiesene Geschlecht, deshalb werden SNOMED-CT-Codes statt des administrativen Geschlechts verwendet. Vorschlag: Eine ConceptMap von den SNOMED-CT-Codes nach`administrative-gender`mit qualifizierten Beziehungen (z. B.**wider**,**narrower**,**inexact**) wird ergänzt, statt eine Äquivalenz zu unterstellen. | Vorschlag: annehmen | nein |

### C. Zur Diskussion

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| [HDB-1077](https://hl7germany.atlassian.net/browse/HDB-1077) | Constraint für die Lateralitätsangabe in Procedure | Ein Verbot doppelter Lateralitätsangaben ist fraglich: Die OPS-Seitenlokalisation dient der Abrechnung,`bodySite`kann spezifischer sein. Mindestens müssen beide Angaben übereinstimmen. Es muss recherchiert werden, wie andere Spezifikationen damit umgehen. | Diskussion | abhängig (**ja**bei einer Invariante mit Schweregrad error,**nein**bei warning) |
| [HDB-1070](https://hl7germany.atlassian.net/browse/HDB-1070) | Verwendung von "pattern" Diskriminatoren | `pattern`ist ab R5 deprecated.**In R4 getestet (SUSHI 3.21.0, IG Publisher 2.3.4):**`#value`mit weiterhin in`pattern[x]`hinterlegten Werten liefert für`Coding`-,`CodeableConcept`- und`Identifier`-Slicings auf`$this`dieselben Validierungsergebnisse wie`#pattern`; SUSHI behält`pattern[x]`bei (nur`(exactly)`erzeugt`fixed[x]`). Lediglich der Deprecation-Hinweis zu`#pattern`entfällt. Betrifft 23 Slicings. Einschränkung: Abgeleitete Profile, die ein geerbtes Slicing mit`#pattern`erneut deklarieren, scheitern bei der Snapshot-Generierung („Slicing rules on differential … do not match those on base“) und müssen ebenfalls umgestellt werden, z. B. Onkologie`mii-pr-onko-diagnose-primaertumor`(`bodySite.coding`). | Diskussion | nein (Instanzen); Migrationshinweis für abgeleitete Profile |
| [HDB-1071](https://hl7germany.atlassian.net/browse/HDB-1071) | Kardinalität von Patient.birthDate | `birthDate`1..1 (mit`data-absent-reason`) muss diskutiert werden: Die MII-Infrastruktur ist weder die ePA noch ISiK und hat andere Datenquellen. | Diskussion | **ja** |
| [HDB-1018](https://hl7germany.atlassian.net/browse/HDB-1018) | Procedure.category Invarianten | Zwei getrennte Entscheidungen:**(a)**eine rein textuelle`Procedure.code`erlauben (ISiK`proc-ISiK-3`) – das**lockert**`sct-ops-1`und`code.coding`1..*, Konsumenten können sich dann nicht mehr auf eine kodierte Prozedur verlassen;**(b)**`proc-ISiK-2`übernehmen (`code.coding.exists() implies category.coding.exists()`) – das**verschärft**die Regeln: Eine mit SNOMED CT kodierte Prozedur ohne`category`ist derzeit konform (`proc-mii-1`verlangt eine Category nur bei OPS-Codes), wäre es dann aber nicht mehr. Die Maintainer befürworten (a) nicht. | Diskussion | (a) Auswirkung auf Konsumenten · (b)**ja** |
| [HDB-1016](https://hl7germany.atlassian.net/browse/HDB-1016) | Encounter.type.Kontaktebene und .diagnosis.use.coding:Diagnosetyp und .hospitalization.admitSource | Kardinalitäten wurden aus Gründen der Rückwärtskompatibilität bisher bewusst nicht verschärft. Diskutieren, ob an ISiK angeglichen wird, und die Abweichungen dokumentieren. | Diskussion | **ja**, falls verschärft |

### D. Vorschlag: annehmen – nur Dokumentation

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| [HDB-1048](https://hl7germany.atlassian.net/browse/HDB-1048) | Aufnahmenummer ungleich Fallnummer | Die Beschreibung der**Aufnahmenummer**im logischen Modell Fall wird korrigiert: Aufnahmenummer und Fallnummer sind unterschiedliche Identifikatoren. Abstimmung mit dem ISiK-Kontaktkonzept. | Vorschlag: annehmen (Doku) | nein |
| [HDB-1010](https://hl7germany.atlassian.net/browse/HDB-1010) | Fallart teilstationär Klarstellung | Dokumentieren, warum teilstationäre Fälle`IMP`(mit Bettenallokation, z. B. Nachtklinik) oder`SS`(ohne Bettenallokation) verwenden können. | Vorschlag: annehmen (Doku) | nein |
| [HDB-1011](https://hl7germany.atlassian.net/browse/HDB-1011) | Bettenstellplatz | Für`Encounter.location:Bett`wird der Begriff „Bettenstellplatz“ verwendet, um den Ort vom Gerät abzugrenzen. Der Slice-Name bleibt unverändert. | Vorschlag: annehmen (Doku) | nein |
| [HDB-1076](https://hl7germany.atlassian.net/browse/HDB-1076) | Slicing auf Encounter.diagnosis.use.coding | Das Slicing auf`coding`ist beabsichtigt: Ein`use`**kann**sowohl ein**Diagnosetyp**- als auch ein**DiagnosesubTyp**-Coding**enthalten**(beide Slices sind optional, 0..1). Der bestehende Best-Practice-Hinweis in den Hinweisen zum Encounter-Profil, der für Diagnosetyp und Diagnosesubtyp getrennte`Encounter.diagnosis`-Einträge empfiehlt, widerspricht dem und wird einschließlich seines Beispiels ersetzt. | Vorschlag: annehmen (Doku) | nein |
| [HDB-1052](https://hl7germany.atlassian.net/browse/HDB-1052) | Extension von Diagnosen ValueSet in Fall-Profile | `mii-vs-fall-diagnosis-use`enthält bereits`DiagnoseTyp`,`Diagnosesubtyp`(CodeSystem KontaktDiagnoseProzedur) und`diagnosis-role`(Binding extensible). Dies wird dokumentiert und mit einem Beispiel ergänzt. | Vorschlag: annehmen (Doku) | nein |
| [HDB-1020](https://hl7germany.atlassian.net/browse/HDB-1020) | Condition .extension | Die Verwendung von`ReferenzPrimaerdiagnose`und`Feststellungsdatum`sowie der Unterschied zwischen`Feststellungsdatum`(klinisches Diagnosedatum) und`onset`(Beginn der Symptomatik) wird auf Basis der Diskussion in Jira beschrieben. | Vorschlag: annehmen (Doku) | nein |
| [HDB-1012](https://hl7germany.atlassian.net/browse/HDB-1012) | Empfehlung Diagnosen an die Kontaktebene | Ein Hinweis zur Empfehlung, Diagnosen an den Abteilungskontakt zu knüpfen, wird unter Berücksichtigung der laufenden ISiK-Diskussion (Stufe 7) ergänzt. | Vorschlag: annehmen (Doku) | nein |
| [HDB-1013](https://hl7germany.atlassian.net/browse/HDB-1013) | UML Referenz Modul zu Patient | Die Verbindung zwischen Fall und Patient (über den**Patientenidentifikator**) wird im UML-Diagramm ergänzt. | Vorschlag: annehmen (Doku) | nein |
| [HDB-939](https://hl7germany.atlassian.net/browse/HDB-939) | Zuordnung - Encounter <-> Account | In Grafik oder Text wird klargestellt, dass einem Account mehrere Einrichtungskontakte zugeordnet sein können. | Vorschlag: annehmen (Doku) | nein |
| [HDB-938](https://hl7germany.atlassian.net/browse/HDB-938) | Station (Ward) -> Location vs. Organization | Beide Möglichkeiten zur Abbildung einer Station werden beschrieben: als`Location`(`physicalType = wa`) oder über die`Organization`des Service Providers. | Vorschlag: annehmen (Doku) | nein |

### E. Antwort geplant

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| [HDB-1017](https://hl7germany.atlassian.net/browse/HDB-1017) | Procedure Extension Durchführungsabsicht | Entwurf: Die Extension erfasst die Absicht einer Prozedur (z. B. kurativ, palliativ, diagnostisch).**Benötigt:**In welchen Dokumentationskontexten die Standorte sie erfassen, um zu beurteilen, ob sie sich als Must Support für die Versorgung (ISiK) eignet. | Antwort geplant | nein |
| [HDB-1021](https://hl7germany.atlassian.net/browse/HDB-1021) | Vitalstatus | Entwurf: Das Profil ist nicht von VitalSignDE abgeleitet, weil es ein anderes Konzept abbildet – VitalSignDE umfasst Vitalparameter (z. B. Blutdruck, Herzfrequenz), das Vitalstatus-Profil dagegen, ob eine Person lebt oder verstorben ist (LOINC 67162-8). | Antwort geplant | nein |
| [HDB-1024](https://hl7germany.atlassian.net/browse/HDB-1024) | Vitalstatus (Observation) .note MS | Entwurf:`note`enthält zusätzliche Freitext-Informationen zum Vitalstatus (z. B. die Quelle der Information).**Benötigt:**Ob die Standorte es in der Praxis nutzen, um die Relevanz für die Versorgung zu beurteilen. | Antwort geplant | nein |
| [HDB-1025](https://hl7germany.atlassian.net/browse/HDB-1025) | Warum Basis und Meta | Entwurf (zu bestätigen): Das Modul Meta enthält modulübergreifende Festlegungen und Konventionen, die alle KDS-Module nachnutzen; das Modul Basis enthält die klinischen Basisprofile. Durch die Trennung können modulübergreifende Regeln in einem eigenen Release-Zyklus weiterentwickelt werden; die Module übernehmen eine neue Meta-Version über eine ausdrückliche Aktualisierung der Abhängigkeit und eine Kompatibilitätsprüfung. | Antwort geplant | nein |
| [HDB-1026](https://hl7germany.atlassian.net/browse/HDB-1026) | Condition.clinicalStatus - KlinischerStatus | `clinicalStatus`ist ein Modifier-Element (`isModifier = true`): Das Entfernen der Must-Support-Kennzeichnung entfernt das Element nicht, und ein Empfänger muss es trotzdem verstehen, wenn ein Sender es befüllt, da es die Bedeutung der Condition ändert (z. B.**resolved**,**inactive**).**Benötigt:**Wie häufig die DIZ-Standorte einen klinischen Status aus den Quellsystemen erhalten. Danach Antwort, ob die Must-Support-Kennzeichnung gerechtfertigt ist. | Antwort geplant | nein |
| [HDB-1022](https://hl7germany.atlassian.net/browse/HDB-1022) | ValueSets Konsolidieren | Entwurf: Wir unterstützen eine gemeinsame Konsolidierung von ValueSets mit der gematik, dem TC Terminologie von HL7 Deutschland und dem Terminologieserver des BfArM (ZTS) und schlagen vor, einen gemeinsamen Kuratierungsprozess zu vereinbaren. Die Bezeichnung von`bd`wird mit HDB-1011 bearbeitet. | Antwort geplant | nein |
| [HDB-1023](https://hl7germany.atlassian.net/browse/HDB-1023) | Fehlende Daten | Entwurf: Wir unterstützen, die Hinweise zum Umgang mit fehlenden Daten gemeinsam mit der gematik in die Basisprofile DE einzubringen, damit sie an einer Stelle gepflegt werden. | Antwort geplant | nein |
| [HDB-1035](https://hl7germany.atlassian.net/browse/HDB-1035) | Mutter-Kind-Beziehung | Entwurf: Nicht Teil dieser Version; wird als zukünftiges Thema vorgemerkt. | Antwort geplant | nein |
| [HDB-1036](https://hl7germany.atlassian.net/browse/HDB-1036) | Mehrlingsschwangerschaft | Entwurf: Nicht Teil dieser Version; wird als zukünftiges Thema vorgemerkt. | Antwort geplant | nein |

### F. Vorschlag: nach Meta verschieben

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| [HDB-1014](https://hl7germany.atlassian.net/browse/HDB-1014) | Meta CpS | Betrifft das CapabilityStatement des Moduls Meta; Verschiebung nach`kerndatensatz-meta`. | Vorschlag: nach Meta verschieben | nein |
| [HDB-1015](https://hl7germany.atlassian.net/browse/HDB-1015) | Externe Quelle github? | Betrifft den Abschnitt Konformität des Moduls Meta; Verschiebung nach`kerndatensatz-meta`. | Vorschlag: nach Meta verschieben | nein |

