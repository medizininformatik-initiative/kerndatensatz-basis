# Downloads - MII Implementation Guide Core Dataset Base v2027.0.0-ballot

* [**Inhaltsverzeichnis**](toc.md)
* **Downloads**

## Downloads

 Diese Seite enthält Übersetzungen aus der Originalsprache, in der der Leitfaden verfasst wurde. Informationen zu diesen Übersetzungen und Anweisungen zum Abgeben von Feedback zu den Übersetzungen finden Sie [hier](translationinfo.md). 

### Downloads

Diese Seite bietet Links zu herunterladbaren Artefakten aus diesem Implementierungsleitfaden.

#### Paketdatei

Die folgende Paketdatei enthält ein NPM-Paket, das von vielen FHIR-Tools verwendet wird. Sie enthält alle ValueSets, Profile, Extensions, Seiten und URLs im IG usw., die als Teil dieser Version des Implementierungsleitfadens definiert sind. Diese Datei **SOLL** die erste Wahl sein, wenn Implementierungsartefakte generiert werden, da sie alle Regeln enthält, die die Profile gültig machen. Implementierer müssen dennoch mit dem Spezifikationsinhalt und den anzuwendenden Profilen vertraut sein, um eine konforme Implementierung zu erstellen. Weitere Informationen finden Sie in der FHIR-Dokumentation zur [Validierung von Profilen und Ressourcen](http://hl7.org/fhir/R4/validation.html).

* [Paket (komprimierter Ordner)](../package.tgz)

#### Herunterladbare Kopie der Spezifikation

Eine herunterladbare Version dieses IGs ist verfügbar, damit sie lokal gehostet werden kann:

* [Herunterladbare Kopie (komprimierter Ordner)](../full-ig.zip)

#### Beispiele

Alle Beispiele in diesem Implementierungsleitfaden stehen zum Download zur Verfügung:

* [XML (komprimierter Ordner)](../examples.xml.zip)
* [JSON (komprimierter Ordner)](../examples.json.zip)

#### Konsolidierte CSV- und Excel-Datei-Darstellungen der Profile

Alle Profilinformationen für den MII Kerndatensatz Basis in einer einzigen CSV- oder Excel-Datei, die für Tester und Analyst*innen hilfreich sein kann, um Elementeigenschaften über Profile hinweg in einer einzigen Tabelle zu überprüfen:

* [CSV (komprimierter Ordner)](../csvs.zip)
* [Excel (komprimierter Ordner)](../excels.zip)

#### Schematrons

Schematrons stehen ebenfalls zum Download zur Verfügung:

* [Schematrons (komprimierter Ordner)](../schematrons.zip)

#### Details zum Implementierungsleitfaden

Der folgende Link zur ImplementationGuide-Ressource definiert die technischen Details dieser Publikation, einschließlich Abhängigkeiten und Veröffentlichungsparameter:

* [MII Kerndatensatz Basis ImplementationGuide-Ressource](ImplementationGuide-mii-ig-base.md)

#### Versionshistorie

Frühere Versionen dieses Implementierungsleitfadens und eine detaillierte Änderungshistorie finden Sie auf der Seite [Versionshistorie](version-history.md).

