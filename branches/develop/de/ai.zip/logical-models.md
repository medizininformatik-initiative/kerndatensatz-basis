# Logische Modelle - MII Implementation Guide Core Dataset Base v2027.0.0-ballot

* [**Inhaltsverzeichnis**](toc.md)
* **Logische Modelle**

## Logische Modelle

Logische Modelle bieten eine konzeptionelle Ansicht der in diesem Implementierungsleitfaden definierten Datenstrukturen. Sie repräsentieren die Datenelemente und ihre Beziehungen unabhängig von der FHIR-Ressourcenstruktur.

Für die MII-Kerndatensatz-Basismodule sind folgende logische Modelle definiert:

### Modul Person

* [Logisches Modell Person](StructureDefinition-mii-lm-person.md) - Konzeptionelles Modell für Patientendemografie, Vitalstatus und identifizierende Informationen

### Modul Fall

* [Logisches Modell Fall](StructureDefinition-mii-lm-fall.md) - Konzeptionelles Modell für Kontakte im Gesundheitswesen

### Modul Diagnose

* [Logisches Modell Diagnose](StructureDefinition-mii-lm-diagnose.md) - Konzeptionelles Modell für Diagnosen und Erkrankungen

### Modul Prozedur

* [Logisches Modell Prozedur](StructureDefinition-mii-lm-prozedur.md) - Konzeptionelles Modell für Prozeduren

-------

Für die entsprechenden FHIR-Ressourcenprofile, die diese logischen Modelle implementieren, siehe [Profile und Erweiterungen](profiles-and-extensions.md).

