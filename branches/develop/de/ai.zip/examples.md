# Beispiele - MII Implementation Guide Core Dataset Base v2027.0.0-ballot

* [**Inhaltsverzeichnis**](toc.md)
* **Beispiele**

## Beispiele

 Diese Seite enthält Übersetzungen aus der Originalsprache, in der der Leitfaden verfasst wurde. Informationen zu diesen Übersetzungen und Anweisungen zum Abgeben von Feedback zu den Übersetzungen finden Sie [hier](translationinfo.md). 

Dieser Implementierungsleitfaden enthält Beispielinstanzen für alle Profile. Eine vollständige Liste aller Beispiele, geordnet nach Ressourcentyp, finden Sie auf der Seite [Artefakte](artifacts.md#beispiel-beispielinstanzen).

-------

**Beispiele:** Alle Beispiele, die in diesem Implementierungsleitfaden verwendet werden, stehen zum Download zur Verfügung:

* [XML](../examples.xml.zip)
* [JSON](../examples.json.zip)

