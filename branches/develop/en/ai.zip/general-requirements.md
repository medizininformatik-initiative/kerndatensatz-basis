# General Requirements - MII Implementation Guide Core Dataset Base v2027.0.0-ballot.rc1

* [**Table of Contents**](toc.md)
* [**Conformance**](conformance.md)
* **General Requirements**

## General Requirements

This page documents requirements common to all MII actors in this guide. The conformance verbs - **SHALL**, **SHOULD**, **MAY** - used in this guide are defined in [FHIR Conformance Rules](http://hl7.org/fhir/R4/conformance-rules.html#conflang).

### MII Conformance Artifacts

The [Profiles and Extensions](profiles-and-extensions.md) page lists the MII Profiles defined for this implementation guide. MII Profile [StructureDefinitions](http://hl7.org/fhir/R4/structuredefinition.html) define the **minimum** elements, extensions, vocabularies, and ValueSets that **SHALL** be present and constrain how the elements are used when using the profile.

The MII Profile elements include **Mandatory** and **Must Support** requirements. Mandatory elements are required and have a minimum cardinality of 1 (min=1). Must Support element Server and Client expectations are defined by MII. The [Must Support](must-support.md) page defines the Server and Client expectations for processing these element requirements and illustrates how they are displayed and documented.

The [Capability Statements](capability-statements.md) page outlines conformance requirements and expectations for MII Servers and Client applications. The MII CapabilityStatements identify the specific profiles and RESTful transactions that need support. The MII Profiles identify the structural constraints, terminology bindings, and invariants. Implementers must refer to the CapabilityStatements for details on the RESTful transactions, specific profiles, and the search parameters applicable to each MII actor.

### Standards and Alignment

The MII core dataset specifications are based, where possible, on international standards and terminologies. In particular, the following standards are highlighted:

* **[International Patient Summary (IPS)](http://hl7.org/fhir/uv/ips/)** - International standard for patient summaries
* **[German Base Profiles (Basisprofil DE R4)](https://ig.fhir.de/basisprofile-de/)** - Adaptation to the general conditions of the German healthcare system
* **[KBV FHIR Specifications](https://simplifier.net/organization/kassenrztlichebundesvereinigungkbv)** - Compatibility with specifications from the National Association of Statutory Health Insurance Physicians
* **[gematik FHIR Specifications](https://simplifier.net/organization/gematik)** - Compatibility with gematik specifications
* **[ISiK (Informationssysteme im Krankenhaus)](https://fachportal.gematik.de/informationen-fuer/isik)** - Reference specification for information systems in hospitals

All elements of the core dataset, adapted to the details and requirements for the use cases of the Medical Informatics Initiative, are described below in the form of FHIR StructureDefinitions. The necessity of adapting the FHIR profiles is explained in textual form on each profile page.

### Conformance Verbs

Requirements in this specification are indicated by the following keywords written in capital letters based on [RFC-2119](https://datatracker.ietf.org/doc/html/rfc2119):

| | | |
| :--- | :--- | :--- |
| MUSS / MÜSSEN | MUST / SHALL | Required, mandatory |
| DARF NICHT / DÜRFEN NICHT | MUST NOT / SHALL NOT | Prohibited |
| VERPFLICHTEND | REQUIRED | Required by specification |
| SOLL / SOLLEN | SHOULD | Recommended |
| SOLL NICHT / SOLLEN NICHT | SHOULD NOT | Not recommended |
| EMPFOHLEN | RECOMMENDED | Recommended |
| KANN / OPTIONAL | MAY | Optional |

### Claiming Conformance to MII Profiles

#### Profile Support

Systems may deploy and support one or more MII Profiles to represent clinical information. They use the profile's content model without any expectations to implement the MII interactions.

To support an MII Profile:

* §general-1:Servers **SHALL** be able to populate all profile data elements that are mandatory and flagged as **Must Support** as defined by that profile's StructureDefinition§
* §general-2:Servers **SHOULD** declare support for an MII Profile by including its official URL in the Server's `CapabilityStatement.rest.resource.supportedProfile` element§ 
* The MII profile's official or "canonical" URL is located on each MII profile page
 

#### Profile Support + Interaction Support

Systems may deploy and support one or more MII Profiles to represent clinical information **and** support the RESTful interactions defined for those resources.

* §general-3:A conformant server **SHALL** be able to populate all profile data elements that are mandatory and/or flagged as **Must Support** as defined by that profile's StructureDefinition§
* §general-4:A conformant server **SHOULD** declare conformance with the appropriate MII CapabilityStatement by including its official URL in the Server's `CapabilityStatement.instantiates` element§
* §general-5:A conformant server **SHALL** specify the full capability details from the MII CapabilityStatement it claims to implement§ 
* §general-6:A conformant server claiming interaction support **SHALL** declare support for the MII Profile by including its official URL in the Server's `CapabilityStatement.rest.resource.supportedProfile` element§
* §general-7:A conformant server claiming interaction support **SHALL** declare support for the MII Profile's FHIR RESTful transactions§
 

### Using Codes in MII Profiles

The following rules summarize the requirements defined by [FHIR Terminology](http://hl7.org/fhir/R4/terminologies.html) for coded elements (CodeableConcept, Coding, and code datatypes).

#### Required Bindings for Coded Elements

[Required binding](http://hl7.org/fhir/R4/terminologies.html#required) to a ValueSet definition means that one of the codes from the specified ValueSet **SHALL** be used. For `CodeableConcept`, which permits multiple codings and a text element, this rule applies to **at least** one of the codings, and only text is **not** valid.

* §general-8:When claiming conformance to a profile with required bindings, Servers **SHALL** provide at least one code from the bound ValueSet (additional codes from other systems **MAY** be provided)§
* §general-9:When claiming conformance to a profile with required bindings, Clients **SHALL** be capable of processing the code from the bound ValueSet§

#### Extensible Binding for Coded Elements

[Extensible binding](http://hl7.org/fhir/R4/terminologies.html#extensible) means that one of the codes from the specified ValueSet **SHALL** be used if an applicable concept is present. If no suitable code exists in the ValueSet, alternate code(s) may be provided. For `CodeableConcept`, which permits multiple codings and a text element, this rule applies to **at least** one of the codings. If only text is available and it has no conceptual overlap with the bound coded values, then just text may be used.

* §general-10:When claiming conformance to a profile with extensible bindings, Servers **SHALL** provide a code from the bound ValueSet **if the concept exists** in the ValueSet or an alternative code **if the concept does not exist** in the ValueSet or text if only text is available§
* §general-11:When claiming conformance to a profile with extensible bindings, Clients **SHALL** be capable of processing codes from the bound ValueSet, alternative codes, or text§

#### Using Multiple Codes with CodeableConcept Datatype

Alternate codes may be provided in addition to the standard codes defined in required or extensible ValueSets. These alternate codes are called "additional codings". They may be equivalent to or narrower in meaning than the standard concept code.

For example, a diagnosis may include both an ICD-10-GM code and a SNOMED CT code for international interoperability:

```
"code": {
  "coding": [
    {
      "system": "http://fhir.de/CodeSystem/bfarm/icd-10-gm",
      "code": "E11.90",
      "display": "Diabetes mellitus, Typ 2, ohne Komplikationen"
    },
    {
      "system": "http://snomed.info/sct",
      "code": "44054006",
      "display": "Diabetes mellitus type 2"
    }
  ]
}

```

### Missing Data

There are situations when information on a particular data element is missing, and the source system does not know the reason for the absence of data. See the [Missing Data](missing-data.md) page for detailed guidance on how to handle missing data in MII profiles.

### FHIR RESTful Search API Requirements

For all supported search interactions in this guide:

* §general-12:Servers **SHALL** support the HTTP `POST`-based search§
* §general-13:Servers **SHALL** support the `GET`-based search§

When searching using different search parameter types:

* **Token search parameters** - [(how to search by token)](http://hl7.org/fhir/R4/search.html#token) 
* §general-14:For token search parameters, the Client **SHALL** provide at least a code value and **MAY** provide both the system and code values§
* §general-15:For token search parameters, the Server **SHALL** support both code-only and system+code token searches§
 
* **Reference search parameters** - [(how to search by reference)](http://hl7.org/fhir/R4/search.html#reference) 
* §general-16:For reference search parameters, the Client **SHALL** provide at least an id value and **MAY** provide both the Type and id values§
* §general-17:For reference search parameters, the Server **SHALL** support both id-only and Type+id reference searches§
 
* **Date search parameters** - [(how to search by date)](http://hl7.org/fhir/R4/search.html#date) 
* §general-18:For date search parameters, the Client **SHALL** provide values precise to the **day** for elements of datatype `date` and to the **second + time offset** for elements of datatype `dateTime`§
* §general-19:For date search parameters, the Server **SHALL** support values precise to the **day** for elements of datatype `date` and to the **second + time offset** for elements of datatype `dateTime`§
 

### Modifier Elements

A FHIR [modifier element](http://hl7.org/fhir/R4/conformance-rules.html#isModifier) is an element that modifies the meaning of a resource element. Not all modifier elements are Mandatory or Must Support, and there is no requirement for supporting them. §general-20:For modifier elements that are Mandatory or **Must Support**, Servers and Clients **SHALL** be able to process them.§

FHIR Clients need to be aware of unexpected modifier elements in the data they receive because they can alter the meaning of the data and can potentially lead to errors or even security risks if not properly handled. Unless a Client determines they can process it safely, rejection is typically the only safe action if unexpected modifier elements are present.

Some examples of modifiers that may not be Must Support elements in MII Profiles include:

* `modifierExtension` element common to all profiles
* `Observation.valueQuantity.comparator`
* `Patient.active`

Implementers **SHOULD** review the profile pages carefully to understand which elements are modifiers and how they affect the interpretation of the resource.

### Handling Source-System Cancellation Flags

Source systems may use technical cancellation or deletion indicators (for example, a SAP **Storno** flag) for encounters, movements, diagnoses, procedures, documents, and other records. Such an indicator is not itself a FHIR lifecycle status and has no resource-independent mapping. Its meaning may range from a planned event that did not occur, through an activity that was interrupted, to a duplicate or otherwise erroneous record.

The time at which the cancellation was recorded is not sufficient to select a FHIR status. In particular, a cancellation recorded after the planned start time does not prove that an encounter or procedure began. Implementers **SHOULD** determine and document the business meaning for each source system, source object type, and, where available, cancellation reason. A generic rule that maps every source-system cancellation flag to `cancelled` or `entered-in-error` **SHOULD NOT** be used.

The following table applies this distinction to the profiles in this guide:

| | | |
| :--- | :--- | :--- |
| The record was created accidentally and should never have been part of the patient's record, for example because of a duplicate entry or wrong-patient assignment | `Encounter.status = entered-in-error`;`Procedure.status = entered-in-error`; or`Condition.verificationStatus = entered-in-error` | The resource is invalid and**SHOULD**be excluded from ordinary clinical and research use. If a Condition is`entered-in-error`,`Condition.clinicalStatus`**MUST NOT**be present. |
| A validly planned encounter did not begin, including when the patient did not attend | `Encounter.status = cancelled` | The encounter did not occur. This applies regardless of whether the cancellation was recorded before or after the planned start time. |
| An encounter began and subsequently ended, including earlier than planned | `Encounter.status = finished`;`Encounter.statusHistory`**MAY**represent preceding lifecycle phases | The encounter occurred and**SHOULD NOT**be represented as`cancelled`. FHIR R4 has no`discontinued`Encounter status. |
| The main activity of a procedure did not begin; preparation may have occurred | `Procedure.status = not-done`; use`Procedure.statusReason`when the reason is known | The procedure was not performed. |
| A procedure was interrupted temporarily and is expected to resume | `Procedure.status = on-hold`; use`Procedure.statusReason`when the reason is known | The status is not terminal; the procedure is expected to resume. |
| A procedure was permanently stopped after part of the main activity occurred | `Procedure.status = stopped`; use`Procedure.statusReason`when the reason is known | The procedure occurred at least in part and**SHOULD NOT**be treated as`not-done`. |
| A diagnosis was ruled out based on diagnostic and clinical evidence | `Condition.verificationStatus = refuted` | This is a valid negative clinical assertion, not an erroneous record. |
| A previously valid diagnosis is no longer active | Use the appropriate`Condition.clinicalStatus`, such as`inactive`,`remission`, or`resolved` | This remains a valid historical diagnosis and is not an erroneous record. |
| The meaning of the source-system cancellation flag cannot be established | No safe generic status mapping exists | The record**SHOULD NOT**be exported with a status that asserts validity or occurrence.`unknown`is not a synonym for a cancellation flag and**SHOULD**only be used where its definition for the resource applies. |

For resource types not listed in the table, implementers **SHOULD** follow the resource-specific FHIR R4 lifecycle and status definitions rather than extrapolating a mapping from another resource type.

#### Initial Load and Later Corrections

If a source record is already known to be an erroneous entry and no audit requirement calls for its representation in the FHIR repository, it **SHOULD** normally be excluded from the initial load. By contrast, a cancelled planned encounter or a procedure that was not done can be meaningful information and **MAY** be retained with the corresponding FHIR status.

If a resource was transferred before the source-system cancellation became known, the ETL process **SHOULD** ensure that the current representation no longer asserts an incorrect state. Where a semantically correct FHIR status exists, the existing resource **SHOULD** be updated while retaining its logical id. If no safe status mapping exists, the resource **SHOULD** be removed from the current dataset, for example using the FHIR RESTful `delete` interaction where the target repository supports it, subject to local retention and audit requirements. Updates or deletions **SHOULD** be propagated to replicated datasets. A status value **SHOULD NOT** be selected merely as a substitute for a technically inconvenient deletion. This guidance does not add RESTful `update` or `delete` requirements; the [MII CapabilityStatements](capability-statements.md) define the interactions required by this guide.

Status changes apply to each resource independently and do not automatically cascade through references. For example, marking an Encounter as `entered-in-error` does not by itself determine the status of related Conditions or Procedures; each related resource **SHOULD** be assessed according to its own source information and real-world meaning.

#### Requirements for Data Use

Status and verification elements that are [modifier elements](http://hl7.org/fhir/R4/conformance-rules.html#isModifier) cannot be safely ignored. Queries, exports, and analyses **SHOULD** therefore define and document resource-specific filters. Records marked `entered-in-error` **SHOULD** be excluded by default. Other statuses require use-case-specific handling: `cancelled` and `not-done` do not represent performed events, `stopped` can represent a partially performed activity, and `refuted` represents a valid assertion that a diagnosis was ruled out.

For further details, see the FHIR R4 guidance on [resource lifecycle and entered-in-error](http://hl7.org/fhir/R4/lifecycle.html#error), the [Implementer's Safety Check List](http://hl7.org/fhir/R4/safety.html), and the definitions of the [Encounter](http://hl7.org/fhir/R4/codesystem-encounter-status.html), [event](http://hl7.org/fhir/R4/codesystem-event-status.html), and [Condition verification](http://hl7.org/fhir/R4/codesystem-condition-ver-status.html) statuses.

-------

For more information, see:

* [Must Support](must-support.md) - Detailed Must Support requirements
* [General Requirements](general-requirements.md) - Additional general requirements
* [Missing Data](missing-data.md) - Guidance for handling missing data
* [Capability Statements](capability-statements.md) - Server and Client capability requirements

