# mii-exa-person-allergyintolerance-1 - MII Implementation Guide Core Dataset Base v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **mii-exa-person-allergyintolerance-1**

## Example AllergyIntolerance: mii-exa-person-allergyintolerance-1

-------

**English**

-------

Profile: [MII PR Person Allergy Intolerance](StructureDefinition-mii-pr-person-allergieunvertraeglichkeit.md)

**clinicalStatus**: Active

**verificationStatus**: Confirmed

**type**: Allergy

**category**: Medication

**criticality**: High Risk

**code**: Penicillin

**patient**: [Maja Julia Van-der-Dussen (official) Female, DoB: 1998-09-19 ( Medical record number: 42285243 (use: usual))](Patient-mii-exa-person-patient-1.md)

**encounter**: [Encounter: extension = ; identifier = Visit number: A1E; status = finished; class = ambulatory (ActCode#AMB); type = Abteilungskontakt; priority = emergency; period = 2020-01-08 07:00:00+0100 --> 2020-01-08 09:00:00+0100](Encounter-mii-exa-fall-kontakt-gesundheitseinrichtung-9.md)

**recordedDate**: 2020-01-08

### Reactions

| | | |
| :--- | :--- | :--- |
| - | **Manifestation** | **Severity** |
| * | Maculopapular eruption | Severe |



## Resource Content

```json
{
  "resourceType" : "AllergyIntolerance",
  "id" : "mii-exa-person-allergyintolerance-1",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/modul-person/StructureDefinition/AllergieUnvertraeglichkeit"]
  },
  "clinicalStatus" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical",
      "code" : "active"
    }]
  },
  "verificationStatus" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/allergyintolerance-verification",
      "code" : "confirmed"
    }]
  },
  "type" : "allergy",
  "category" : ["medication"],
  "criticality" : "high",
  "code" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "764146007",
      "display" : "Penicillin"
    }]
  },
  "patient" : {
    "reference" : "Patient/mii-exa-person-patient-1"
  },
  "encounter" : {
    "reference" : "Encounter/mii-exa-fall-kontakt-gesundheitseinrichtung-9"
  },
  "recordedDate" : "2020-01-08",
  "reaction" : [{
    "manifestation" : [{
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "code" : "247471006",
        "display" : "Maculopapular eruption"
      }]
    }],
    "severity" : "severe"
  }]
}

```
