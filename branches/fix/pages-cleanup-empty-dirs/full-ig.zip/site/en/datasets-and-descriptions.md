# Datasets and Descriptions - MII Implementation Guide Core Dataset Base v2027.0.0-ballot

* [**Table of Contents**](toc.md)
* [**Guidance**](guidance.md)
* **Datasets and Descriptions**

## Datasets and Descriptions

Logical models provide a conceptual view of the data structures defined in this implementation guide. They represent the data elements and their relationships independent of the FHIR resource structure, making them easier to understand for domain experts and researchers.

For a complete list of all logical models, see the [Logical Models Overview](logical-models.md).

The following logical models are defined for the MII core dataset base modules:

### Person Module

* [Person Logical Model](StructureDefinition-mii-lm-person.md) - Conceptual model for patient demographics, vital status, and identifying information

### Treatment Case Module

* [Treatment Case Logical Model](StructureDefinition-mii-lm-fall.md) - Conceptual model for encounters and healthcare contacts

### Diagnosis Module

* [Diagnosis Logical Model](StructureDefinition-mii-lm-diagnose.md) - Conceptual model for diagnoses and conditions

### Procedure Module

* [Procedure Logical Model](StructureDefinition-mii-lm-prozedur.md) - Conceptual model for procedures and interventions

-------

For the corresponding FHIR resource profiles that implement these logical models, see [Profiles and Extensions](profiles-and-extensions.md).

