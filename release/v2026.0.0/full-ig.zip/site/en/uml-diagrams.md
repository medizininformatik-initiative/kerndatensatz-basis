# UML Diagrams - MII Implementation Guide Core Dataset Base v2026.0.0

## UML Diagrams

This page provides UML class diagrams for the logical models of the MII core dataset base modules. These diagrams illustrate the relationships between the different data elements and classes.

#### Person Module

The following diagram shows the logical structure of the Person module:

-------

#### Treatment Case Module

The following diagram shows the logical structure of the Person module:

#### Diagnosis Module

The following diagram shows the logical structure of the Person module:

#### Procedure Module

The following diagram shows the logical structure of the Person module:

