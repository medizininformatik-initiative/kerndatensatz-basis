# UML Diagramme - MII Implementation Guide Core Dataset Base v2026.0.0

## UML Diagramme

 
Diese Seite enthält Übersetzungen aus der Originalsprache, in der der Leitfaden verfasst wurde. Informationen zu diesen Übersetzungen und Anweisungen zum Abgeben von Feedback zu den Übersetzungen finden Sie[hier](translationinfo.md). 

Diese Seite enthält UML-Klassendiagramme für die logischen Modelle der MII-Kerndatensatz-Basismodule. Diese Diagramme veranschaulichen die Beziehungen zwischen den verschiedenen Datenelementen und Klassen.

#### Modul Person

Das folgende Diagramm zeigt die logische Struktur des Moduls Person:

-------

#### Modul Fall

Das folgende Diagramm zeigt die logische Struktur des Moduls Fall:

#### Modul Diagnose

Das folgende Diagramm zeigt die logische Struktur des Moduls Diagnose:

#### Modul Prozedur

Das folgende Diagramm zeigt die logische Struktur des Moduls Prozedur:

