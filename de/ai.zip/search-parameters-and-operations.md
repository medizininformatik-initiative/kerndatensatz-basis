# Suchparameter und Operations - MII Implementation Guide Core Dataset Base v2026.0.0-dev.1

## Suchparameter und Operations

 
Diese Seite enthält Übersetzungen aus der Originalsprache, in der der Leitfaden verfasst wurde. Informationen zu diesen Übersetzungen und Anweisungen zum Abgeben von Feedback zu den Übersetzungen finden Sie[hier](translationinfo.md). 

