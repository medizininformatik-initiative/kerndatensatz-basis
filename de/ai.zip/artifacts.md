# Artefaktübersicht - MII Implementation Guide Core Dataset Base v2026.0.0-dev.1

## Artefaktübersicht

 
There is no translation page available for the current page, so it has been rendered in the default language 

