# Examples - MII Implementation Guide Core Dataset Base v2026.0.0-dev.1

## Examples

This Implementation Guide includes example instances for all profiles. See the [Artifacts](artifacts.md#example-example-instances) page for a complete list of all examples organized by resource type.

-------

**Examples:** all the examples that are used in this Implementation Guide available for download:

* [XML](../examples.xml.zip)
* [JSON](../examples.json.zip)

