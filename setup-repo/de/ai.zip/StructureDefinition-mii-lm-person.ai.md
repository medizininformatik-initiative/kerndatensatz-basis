# MII LM Person - MII Implementation Guide Core Dataset Base v2026.0.0-dev.1

## Logisches Modell: MII LM Person 

 
Logische Repräsentation des Basismoduls Person 

**Usages:**

* This Logical Model is not used by any profiles in this Implementation Guide

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/de.medizininformatikinitiative.kerndatensatz.base|current/StructureDefinition/mii-lm-person)

**Changes since version {current}:**

* New Content

### Formale Ansichten des Profilinhalts

 [Beschreibung von Profilen, Differentials, Snapshots und deren Repräsentationen](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Differential-Tabelle](#tabs-diff) 
*  [Snapshot-Tabelle](#tabs-snap) 
*  [Statistiken/Referenzen](#tabs-summ) 
*  [Alle](#tabs-all) 

Diese Struktur ist abgeleitet von [Element](http://hl7.org/fhir/R4/datatypes.html#Element) 

#### Constraints

Diese Struktur ist abgeleitet von [Element](http://hl7.org/fhir/R4/datatypes.html#Element) 

**Summary**

Mandatory: 0 element(13 nested mandatory elements)

 **Differential-Ansicht** 

Diese Struktur ist abgeleitet von [Element](http://hl7.org/fhir/R4/datatypes.html#Element) 

 **Snapshot-AnsichtView** 

#### Constraints

Diese Struktur ist abgeleitet von [Element](http://hl7.org/fhir/R4/datatypes.html#Element) 

**Summary**

Mandatory: 0 element(13 nested mandatory elements)

 

Weitere Repräsentationen des Profils: [CSV](../StructureDefinition-mii-lm-person.csv), [Excel](../StructureDefinition-mii-lm-person.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "mii-lm-person",
  "extension" : [
    {
      "url" : "https://www.medizininformatik-initiative.de/fhir/modul-meta/StructureDefinition/mii-ex-meta-license-codeable",
      "valueCodeableConcept" : {
        "coding" : [
          {
            "system" : "http://hl7.org/fhir/spdx-license",
            "code" : "CC-BY-4.0",
            "display" : "Creative Commons Attribution 4.0 International"
          }
        ]
      }
    }
  ],
  "url" : "https://www.medizininformatik-initiative.de/fhir/core/modul-person/StructureDefinition/LogicalModel/Person",
  "version" : "2026.0.0-dev.1",
  "name" : "MII_LM_Person",
  "title" : "MII LM Person",
  "status" : "active",
  "date" : "2024-12-04",
  "publisher" : "Medical Informatics Initiative (MII)",
  "_publisher" : {
    "extension" : [
      {
        "extension" : [
          {
            "url" : "lang",
            "valueCode" : "de"
          },
          {
            "url" : "content",
            "valueString" : "Medizininformatik-Initiative (MII)"
          }
        ],
        "url" : "http://hl7.org/fhir/StructureDefinition/translation"
      }
    ]
  },
  "contact" : [
    {
      "name" : "Medical Informatics Initiative (MII)",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://www.medizininformatik-initiative.de/en"
        }
      ]
    }
  ],
  "description" : "Logische Repräsentation des Basismoduls Person",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "DE",
          "display" : "Germany"
        }
      ]
    }
  ],
  "fhirVersion" : "4.0.1",
  "mapping" : [
    {
      "identity" : "rim",
      "uri" : "http://hl7.org/v3",
      "name" : "RIM Mapping"
    }
  ],
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://www.medizininformatik-initiative.de/fhir/core/modul-person/StructureDefinition/LogicalModel/Person",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Element",
  "derivation" : "specialization",
  "differential" : {
    "element" : [
      {
        "id" : "Person",
        "path" : "Person",
        "short" : "-- Überschrift --",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "-- Heading --"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Logische Repräsentation des Basismoduls Person"
      },
      {
        "id" : "Person.Name",
        "path" : "Person.Name",
        "short" : "Vollständiger Name einer Person.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Full name of a person"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Vollständiger Name einer Person.",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "Person.Name.Vorname",
        "path" : "Person.Name.Vorname",
        "short" : "Vollständiger Vorname einer Person.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Full given name of a person"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Vollständiger Vorname einer Person.",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "Person.Name.Nachname",
        "path" : "Person.Name.Nachname",
        "short" : "Nachname einer Person ohne Vor- und Zusätze. Dient z.B. der alphabetischen Einordnung des Namens.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Last name of a person without prefixes and suffixes. Serves e.g. the alphabetical classification of the name."
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Nachname einer Person ohne Vor- und Zusätze. Dient z.B. der alphabetischen Einordnung des Namens.",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "Person.Name.Familienname",
        "path" : "Person.Name.Familienname",
        "short" : "Der vollständige Familienname, einschließlich aller Vorsatz- und Zusatzwörter, mit Leerzeichen getrennt.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "The full family name, including all prefix and suffix words, separated by spaces."
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Der vollständige Familienname, einschließlich aller Vorsatz- und Zusatzwörter, mit Leerzeichen getrennt.",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "Person.Name.Vorsatzwort",
        "path" : "Person.Name.Vorsatzwort",
        "short" : "Vorsatzwort wie z.B.: von, van, zu Vgl. auch VSDM-Spezifikation der Gematik (Versichertenstammdatenmanagement, \"eGK\")",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Prefix word such as: \"von\", \"van\", \"zu\", cf. also VSDM specification of Gematik (Versichertenstammdatenmanagement, \"eGK\")"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Vorsatzwort wie z.B.: von, van, zu Vgl. auch VSDM-Spezifikation der Gematik (Versichertenstammdatenmanagement, \"eGK\")",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "Person.Name.Namenszusatz",
        "path" : "Person.Name.Namenszusatz",
        "short" : "Namenszusatz als Bestandteil das Nachnamens, wie in VSDM (Versichertenstammdatenmanagement, \"eGK\") definiert. Beispiele: Gräfin, Prinz oder Fürst",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Name suffix as part of the last name, as defined in VSDM (Versichertenstammdatenmanagement, \"eGK\"). Examples: Countess, Prince, or Prince"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Namenszusatz als Bestandteil das Nachnamens, wie in VSDM (Versichertenstammdatenmanagement, \"eGK\") definiert. Beispiele: Gräfin, Prinz oder Fürst",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "Person.Name.Praefix",
        "path" : "Person.Name.Praefix",
        "short" : "Namensteile vor dem Vornamen, z.B. akademischer Grad",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Parts of the name before the first name, e.g. academic degree"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Namensteile vor dem Vornamen, z.B. akademischer Grad",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "Person.Name.Praefix.ArtdesPraefixes",
        "path" : "Person.Name.Praefix.ArtdesPraefixes",
        "short" : "Art des Präfixes, z.B. \"AC\" für Akademische Titel",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Type of prefix, e.g. \"AC\" for Academic Titel"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Art des Präfixes, z.B. \"AC\" für Akademische Titel",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "Person.Name.Geburtsname",
        "path" : "Person.Name.Geburtsname",
        "short" : "Familienname einer Person zum Zeitpunkt ihrer Geburt. Kann sich danach z.B. durch Heirat und Annahme eines anderen Familiennamens ändern.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Family name of a person at the time of his or her birth. Can change afterwards, e.g. by marriage and adoption of another family name."
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Familienname einer Person zum Zeitpunkt ihrer Geburt. Kann sich danach z.B. durch Heirat und Annahme eines anderen Familiennamens ändern.",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "Person.Demographie",
        "path" : "Person.Demographie",
        "short" : "Das Basismodul Demographie enthält demographische Parameter (Alter, Geschlecht etc.).",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "The basic demography module contains demographic parameters (age, gender, etc.)."
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Das Basismodul Demographie enthält demographische Parameter (Alter, Geschlecht etc.).",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "Person.Demographie.AdministrativesGeschlecht",
        "path" : "Person.Demographie.AdministrativesGeschlecht",
        "short" : "Administratives Geschlecht der Person",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Administrative sex of the person"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Administratives Geschlecht der Person",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "Person.Demographie.Geburtsdatum",
        "path" : "Person.Demographie.Geburtsdatum",
        "short" : "Geburtsdatum des Person.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Date of birth of the patient"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Geburtsdatum des Person.",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "date"
          }
        ]
      },
      {
        "id" : "Person.Demographie.Adresse",
        "path" : "Person.Demographie.Adresse",
        "short" : "Vollständige Anschrift einer Person für die postlische Kommunikation.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Full address of a person for postal communication."
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Vollständige Anschrift einer Person für die postlische Kommunikation.",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "Person.Demographie.Adresse.Strassenanschrift",
        "path" : "Person.Demographie.Adresse.Strassenanschrift",
        "short" : "Eine Adresse für die Strassenanschrift gemäß postalischer Konventionen. Bei Stadtstaaten einschließlich Bezirken.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Postal code according to the conventions valid in the respective country. For persons from city states including the city district"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Eine Adresse für die Strassenanschrift gemäß postalischer Konventionen. Bei Stadtstaaten einschließlich Bezirken.",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "Person.Demographie.Adresse.Strassenanschrift.Land",
        "path" : "Person.Demographie.Adresse.Strassenanschrift.Land",
        "short" : "Ländercode nach ISO 3166.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Country code according to ISO 3166"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Ländercode nach ISO 3166.",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "Person.Demographie.Adresse.Strassenanschrift.PLZ",
        "path" : "Person.Demographie.Adresse.Strassenanschrift.PLZ",
        "short" : "Postleitzahl gemäß der im jeweiligen Land gültigen Konventionen.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Postal code according to the conventions valid in the respective country"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Postleitzahl gemäß der im jeweiligen Land gültigen Konventionen.",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "Person.Demographie.Adresse.Strassenanschrift.Wohnort",
        "path" : "Person.Demographie.Adresse.Strassenanschrift.Wohnort",
        "short" : "Bei Personen aus Stadtstaaten inklusive des Stadtteils.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "For persons from city states including the city district"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Bei Personen aus Stadtstaaten inklusive des Stadtteils.",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "Person.Demographie.Adresse.Strassenanschrift.Strasse",
        "path" : "Person.Demographie.Adresse.Strassenanschrift.Strasse",
        "short" : "Straßenname mit Hausnummer oder Postfach sowie weitere Angaben zur Zustellung.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Street name with house number or P.O. Box and other delivery details"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Straßenname mit Hausnummer oder Postfach sowie weitere Angaben zur Zustellung.",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "Person.Demographie.Adresse.Postfach",
        "path" : "Person.Demographie.Adresse.Postfach",
        "short" : "Eine Adresse für ein Postfach gemäß postalischer Konventionen. Bei Stadtstaaten einschließlich Bezirken.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Postal code according for a P.O box to the conventions valid in the respective country. For persons from city states including the city district."
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Eine Adresse für ein Postfach gemäß postalischer Konventionen. Bei Stadtstaaten einschließlich Bezirken.",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "Person.Demographie.Adresse.Postfach.Land",
        "path" : "Person.Demographie.Adresse.Postfach.Land",
        "short" : "Ländercode nach ISO 3166.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Country code according to ISO 3166"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Ländercode nach ISO 3166.",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "Person.Demographie.Adresse.Postfach.PLZ",
        "path" : "Person.Demographie.Adresse.Postfach.PLZ",
        "short" : "Postleitzahl gemäß der im jeweiligen Land gültigen Konventionen.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Postal code according to the conventions valid in the respective country"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Postleitzahl gemäß der im jeweiligen Land gültigen Konventionen.",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "Person.Demographie.Adresse.Postfach.Wohnort",
        "path" : "Person.Demographie.Adresse.Postfach.Wohnort",
        "short" : "Bei Personen aus Stadtstaaten inklusive des Stadtteils.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "For persons from city states including the city district"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Bei Personen aus Stadtstaaten inklusive des Stadtteils.",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "Person.Demographie.Adresse.Postfach.Strasse",
        "path" : "Person.Demographie.Adresse.Postfach.Strasse",
        "short" : "Straßenname mit Hausnummer oder Postfach sowie weitere Angaben zur Zustellung.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Street name with house number or P.O. Box and other delivery details"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Straßenname mit Hausnummer oder Postfach sowie weitere Angaben zur Zustellung.",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "Person.Demographie.Vitalstatus",
        "path" : "Person.Demographie.Vitalstatus",
        "short" : "Gibt an, ob ein Patient verstorben ist. Falls ja, zudem den Zeitpunkt.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Indicates whether a patient has died. If yes, also the time is recorded."
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Gibt an, ob ein Patient verstorben ist. Falls ja, zudem den Zeitpunkt.",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "Person.Demographie.Vitalstatus.PatientVerstorben",
        "path" : "Person.Demographie.Vitalstatus.PatientVerstorben",
        "short" : "Gibt an, ob der Patient am Leben oder verstorben ist.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Indicates whether the patient is alive or deceased."
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Gibt an, ob der Patient am Leben oder verstorben ist.",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "boolean"
          }
        ]
      },
      {
        "id" : "Person.Demographie.Vitalstatus.Todeszeitpunkt",
        "path" : "Person.Demographie.Vitalstatus.Todeszeitpunkt",
        "short" : "Gibt den Todeszeitpunkt des Patienten an, falls dieser im KH verstorben ist. Ansonsten \"Null Flavor\".",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Indicates the time of death of the patient, if the patient died in the hospital. Otherwise \"Null flavor\"."
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Gibt den Todeszeitpunkt des Patienten an, falls dieser im KH verstorben ist. Ansonsten \"Null Flavor\".",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "dateTime"
          }
        ]
      },
      {
        "id" : "Person.Demographie.Vitalstatus.Informationsquelle",
        "path" : "Person.Demographie.Vitalstatus.Informationsquelle",
        "short" : "Quelle des Vitalstatus.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Source of vital status"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Quelle des Vitalstatus.",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "Person.Demographie.Vitalstatus.ZeitpunktFeststellungDesVitalstatus",
        "path" : "Person.Demographie.Vitalstatus.ZeitpunktFeststellungDesVitalstatus",
        "short" : "Letzter bekannter Zeitpunkt oder Zeitraum, zudem ein Vitalstatus festgestellt wurde",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Last known point in time at which a vital status was recorded"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Letzter bekannter Zeitpunkt oder Zeitraum, zudem ein Vitalstatus festgestellt wurde",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "dateTime"
          }
        ]
      },
      {
        "id" : "Person.Demographie.Vitalstatus.Todesursache",
        "path" : "Person.Demographie.Vitalstatus.Todesursache",
        "short" : "Todesursache mit ICD-10-WHO kodiert.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Reason for patient's death. Coded per ICD-10-WHO."
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Todesursache mit ICD-10-WHO kodiert.",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "CodeableConcept"
          }
        ]
      },
      {
        "id" : "Person.PatientIn",
        "path" : "Person.PatientIn",
        "short" : "Person, die in einer oder mehreren Gesundheitseinrichtungen behandelt wird",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Person receiving treatment in one or more health care facilities"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Person, die in einer oder mehreren Gesundheitseinrichtungen behandelt wird",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "Person.PatientIn.PatientenIdentifikator",
        "path" : "Person.PatientIn.PatientenIdentifikator",
        "short" : "Identifikation des Patienten in Verschiedenen Gesundheitseinrichtungen, Einrichtungskennzeichen kann als \"Codesystem\" gesehen werden, und Patienten-Identifikator als \"Code\"",
        "definition" : "Identifikation des Patienten in Verschiedenen Gesundheitseinrichtungen, Einrichtungskennzeichen kann als \"Codesystem\" gesehen werden, und Patienten-Identifikator als \"Code\"",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "Person.PatientIn.PatientenIdentifikator.PatientenIdentifikator",
        "path" : "Person.PatientIn.PatientenIdentifikator.PatientenIdentifikator",
        "short" : "Gesundheitseinrichtungs-eigene Identifikationsnummer für einen Patienten",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Health facility unique identification number for a patient."
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Gesundheitseinrichtungs-eigene Identifikationsnummer für einen Patienten",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Identifier"
          }
        ]
      },
      {
        "id" : "Person.PatientIn.PatientenIdentifikator.PatientenIdentifikatorKontext",
        "path" : "Person.PatientIn.PatientenIdentifikator.PatientenIdentifikatorKontext",
        "short" : "Der Kontext des Patienten-Identifikators um den Patienten-Identifikator zu Beschreiben, da der Patient innerhalb einer Gesundheitseinrichtung möglicherweise pro System eine Nummer (Im Krankenhaus: Labor, Radiologie, Internistische Station etc.) bekommt.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "The context of the patient identifier to describe the patient identifier, since the patient within a healthcare facility may be assigned a number per system (in the hospital: \"laboratory\", \"radiology\", \"internal medicine ward\", etc.)."
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Der Kontext des Patienten-Identifikators um den Patienten-Identifikator zu Beschreiben, da der Patient innerhalb einer Gesundheitseinrichtung möglicherweise pro System eine Nummer (Im Krankenhaus: Labor, Radiologie, Internistische Station etc.) bekommt.",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "CodeableConcept"
          }
        ]
      },
      {
        "id" : "Person.PatientIn.Versicherung",
        "path" : "Person.PatientIn.Versicherung",
        "short" : "Aktuell gültige Versicherung der Patient:in welcher zur Abrechnung der Behandlungsleistung verwendet wird.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Patient's current valid insurance which is used to bill the medical healthcare services."
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Aktuell gültige Versicherung der Patient:in welcher zur Abrechnung der Behandlungsleistung verwendet wird.",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "Person.PatientIn.Versicherung.InstitutionskennzeichenDerKrankenkasse",
        "path" : "Person.PatientIn.Versicherung.InstitutionskennzeichenDerKrankenkasse",
        "short" : "Die Institutionskennzeichen (kurz: IK) sind bundesweit eindeutige, neunstellige Zahlen, mit deren Hilfe Abrechnungen und Qualitätssicherungsmaßnahmen im Bereich der deutschen Sozialversicherung einrichtungsübergreifend abgewickelt werden können.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "The institutional identifiers (IK for short) are nationwide unique nine-digit numbers that can be used to process billing and quality assurance measures across institutions in the German social insurance sector."
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Die Institutionskennzeichen (kurz: IK) sind bundesweit eindeutige, neunstellige Zahlen, mit deren Hilfe Abrechnungen und Qualitätssicherungsmaßnahmen im Bereich der deutschen Sozialversicherung einrichtungsübergreifend abgewickelt werden können.",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "string"
          }
        ],
        "maxLength" : 9
      },
      {
        "id" : "Person.PatientIn.Versicherung.Versicherungstyp",
        "path" : "Person.PatientIn.Versicherung.Versicherungstyp",
        "short" : "Versicherungstyp des Patienten",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Insurance type of the patient"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Versicherungstyp des Patienten",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "CodeableConcept"
          }
        ]
      },
      {
        "id" : "Person.PatientIn.Versicherung.Versichertennummer",
        "path" : "Person.PatientIn.Versicherung.Versichertennummer",
        "short" : "Angaben zur Identifikation der versicherten Person",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Information for the identification of the insured person"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Angaben zur Identifikation der versicherten Person",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "Person.PatientIn.Versicherung.Versichertennummer.VersichertenIDGKV",
        "path" : "Person.PatientIn.Versicherung.Versichertennummer.VersichertenIDGKV",
        "short" : "Unveränderlicher Teil der Krankenversichertennummer (VersichertenID) bei GKV Patienten. Diese findet sich z.B. auf der Mitgliedskarte der Krankenkasse.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Unchangeable part of the health insurance number (insured ID) for SHI patients. This can be found, for example, on the health insurance compan's membership card."
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Unveränderlicher Teil der Krankenversichertennummer (VersichertenID) bei GKV Patienten. Diese findet sich z.B. auf der Mitgliedskarte der Krankenkasse.",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "Person.PatientIn.Versicherung.Versichertennummer.VersichertennummerPKV",
        "path" : "Person.PatientIn.Versicherung.Versichertennummer.VersichertennummerPKV",
        "short" : "Versichertennummer bei PKV Patienten. Vergabe erfolgt durch die jeweilige Private Krankenversicherung.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Insurance number for private health insurance patients. The number is assigned by the respective private health insurance company."
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Versichertennummer bei PKV Patienten. Vergabe erfolgt durch die jeweilige Private Krankenversicherung.",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "string"
          }
        ]
      },
      {
        "id" : "Person.ProbandIn",
        "path" : "Person.ProbandIn",
        "short" : "Person, die an einer Studie teilnimmt (unter Umständen, während sie Patient:in in einer Gesundheitseinrichtung ist)",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Person participating in a study (in some circumstances, while being a patient in a health care facility)"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Person, die an einer Studie teilnimmt (unter Umständen, während sie Patient:in in einer Gesundheitseinrichtung ist)",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "Person.ProbandIn.SubjektIdentifizierungscode",
        "path" : "Person.ProbandIn.SubjektIdentifizierungscode",
        "short" : "Eindeutiger Identifikator eines Patienten im Kontext eines Forschungsprojekts (klinische Studie, Use Case)",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Unique identifier of a patient in the context of a research project (clinical study, use case)"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Eindeutiger Identifikator eines Patienten im Kontext eines Forschungsprojekts (klinische Studie, Use Case)",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Identifier"
          }
        ]
      },
      {
        "id" : "Person.ProbandIn.Rechtsgrundlage",
        "path" : "Person.ProbandIn.Rechtsgrundlage",
        "short" : "Rechtsgrundlage (z.B. Einwilligung) aufgrund die PatientIn in die Studie eingeschlossen werden darf.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Legal basis (e.g. consent) on the basis of which the patient may be included in the study."
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Rechtsgrundlage (z.B. Einwilligung) aufgrund die PatientIn in die Studie eingeschlossen werden darf.",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Reference",
            "targetProfile" : ["http://hl7.org/fhir/StructureDefinition/Consent"]
          }
        ]
      },
      {
        "id" : "Person.ProbandIn.BeginnTeilnahme",
        "path" : "Person.ProbandIn.BeginnTeilnahme",
        "short" : "Beginn der Teilnahme der Person an der Studie.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Start of the person's participation in the study"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Beginn der Teilnahme der Person an der Studie.",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "dateTime"
          }
        ]
      },
      {
        "id" : "Person.ProbandIn.EndeTeilnahme",
        "path" : "Person.ProbandIn.EndeTeilnahme",
        "short" : "Ende der Teilnahme der Person an der Studie.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "End of the person's participation in the study"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Ende der Teilnahme der Person an der Studie.",
        "min" : 0,
        "max" : "1",
        "type" : [
          {
            "code" : "dateTime"
          }
        ]
      },
      {
        "id" : "Person.ProbandIn.StatusDerTeilnahme",
        "path" : "Person.ProbandIn.StatusDerTeilnahme",
        "short" : "Stand der Teilnahme einer Person an der Studie, z.B. eingeschlossen, widerrufen, abgeschlossen etc.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Status of a person's participation in the study, e.g., \"included\", \"revoked\", \"completed\", etc."
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Stand der Teilnahme einer Person an der Studie, z.B. eingeschlossen, widerrufen, abgeschlossen etc.",
        "min" : 1,
        "max" : "1",
        "type" : [
          {
            "code" : "code"
          }
        ]
      },
      {
        "id" : "Person.ProbandIn.BezeichnungDerStudie",
        "path" : "Person.ProbandIn.BezeichnungDerStudie",
        "short" : "Identifikator der Studie",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Unique id of the study"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Identifikator der Studie",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Identifier"
          }
        ]
      },
      {
        "id" : "Person.PatientInPseudonym",
        "path" : "Person.PatientInPseudonym",
        "short" : "Pseudonymisierte Repräsentation einer dazueghörigen Patient:in",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Pseudonymised representation of a corresponding Patient"
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Pseudonymisierte Repräsentation einer dazueghörigen Patient:in",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "BackboneElement"
          }
        ]
      },
      {
        "id" : "Person.PatientInPseudonym.Pseudonym",
        "path" : "Person.PatientInPseudonym.Pseudonym",
        "short" : "Neu generierte Identifikation der PatientIn mit Bezug zum Original-Identifikator in einer Treuhandstelle.",
        "_short" : {
          "extension" : [
            {
              "extension" : [
                {
                  "url" : "lang",
                  "valueCode" : "en"
                },
                {
                  "url" : "content",
                  "valueString" : "Newly generated identification of the patient with reference to the original identifier in a trust center."
                }
              ],
              "url" : "http://hl7.org/fhir/StructureDefinition/translation"
            }
          ]
        },
        "definition" : "Neu generierte Identifikation der PatientIn mit Bezug zum Original-Identifikator in einer Treuhandstelle.",
        "min" : 0,
        "max" : "*",
        "type" : [
          {
            "code" : "Identifier"
          }
        ]
      }
    ]
  }
}

```
